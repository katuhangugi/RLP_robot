from os import path 
import numpy as np
from homestri_ur5e_rl.controllers.operational_space_controller import OperationalSpaceController, TargetType
from gymnasium import spaces
from gym.envs.robotics import rotations, robot_env, utils

# from gymnasium import GoalEnv
from homestri_ur5e_rl.envs.mujoco.mujoco_env import MujocoEnv
from gymnasium_robotics.utils.mujoco_utils import MujocoModelNames, robot_get_obs

try:
    import mujoco
except ImportError as e:
    MUJOCO_IMPORT_ERROR = e
else:
    MUJOCO_IMPORT_ERROR = None

np.set_printoptions(formatter={'float': lambda x: "{0:0.5f}".format(x)})

DEFAULT_CAMERA_CONFIG = {
    "distance": 2.2,
    "azimuth": 90.0,
    "elevation": -20.0,
    "lookat": np.array([0, 0, 1]),
}

class Ur5PickAndPlace(robot_env.RobotEnv):
    metadata = {
        "render_modes": ["human", "rgb_array", "depth_array"],
        "render_fps": 12,
    }

    def __init__(
        self,
        model_path="../assets/base_robot/ur5_pick_and_place.xml",
        frame_skip=40,
        default_camera_config: dict = DEFAULT_CAMERA_CONFIG,
        **kwargs,
    ):
        xml_file_path = path.join(path.dirname(path.realpath(__file__)), model_path)
        observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(28,), dtype=np.float32)

        self._env = MujocoEnv(
            xml_file_path,
            frame_skip,
            observation_space,
            default_camera_config=default_camera_config,
            **kwargs,
        )

        self.model = self._env.model
        self.data = self._env.data
        self.sim = self._env.sim
        self.viewer = self._env.viewer
        self.frame_skip = frame_skip

        self.model_names = MujocoModelNames(self.model)

        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(7,), dtype=np.float32)
        self.observation_space = spaces.Dict({
            'observation': observation_space,
            'achieved_goal': spaces.Box(-np.inf, np.inf, shape=(3,), dtype=np.float32),
            'desired_goal': spaces.Box(-np.inf, np.inf, shape=(3,), dtype=np.float32),
        })

        self.controller = OperationalSpaceController(
            model=self.model, 
            data=self.data, 
            model_names=self.model_names,
            eef_name='robot0:eef_site', 
            joint_names=[
                'robot0:ur5e:shoulder_pan_joint',
                'robot0:ur5e:shoulder_lift_joint',
                'robot0:ur5e:elbow_joint',
                'robot0:ur5e:wrist_1_joint',
                'robot0:ur5e:wrist_2_joint',
                'robot0:ur5e:wrist_3_joint',
            ],
            actuator_names=[
                'robot0:ur5e:shoulder_pan',
                'robot0:ur5e:shoulder_lift',
                'robot0:ur5e:elbow',
                'robot0:ur5e:wrist_1',
                'robot0:ur5e:wrist_2',
                'robot0:ur5e:wrist_3',
            ],
            min_effort=[-150]*6,
            max_effort=[150]*6,
            target_type=TargetType.TWIST,
            kp=200.0,
            ko=200.0,
            kv=50.0,
            vmax_xyz=0.2,
            vmax_abg=1.0,
            null_damp_kv=10,
        )

        self.init_qvel = self.data.qvel.copy()
        self.init_ctrl = self.data.ctrl.copy()
        self._setup_initial_qpos()
        self.goal = self._sample_goal()

    def _setup_initial_qpos(self):
        self.init_qpos_config = {
            "robot0:ur5e:shoulder_pan_joint": 0,
            "robot0:ur5e:shoulder_lift_joint": -np.pi / 2.0,
            "robot0:ur5e:elbow_joint": -np.pi / 2.0,
            "robot0:ur5e:wrist_1_joint": -np.pi / 2.0,
            "robot0:ur5e:wrist_2_joint": np.pi / 2.0,
            "robot0:ur5e:wrist_3_joint": 0,
        }
        for joint_name, joint_pos in self.init_qpos_config.items():
            joint_id = self.model_names.joint_name2id[joint_name]
            qpos_id = self.model.jnt_qposadr[joint_id]
            self._env.init_qpos[qpos_id] = joint_pos

    def _get_obs(self):
        robot_qpos, robot_qvel = robot_get_obs(self.model, self.data, self.model_names.joint_names)
        return np.concatenate((robot_qpos.copy(), robot_qvel.copy()))

    def get_gripper_pose(self):
        site_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_SITE, "robot0:eef_site")
        return self.data.site_xpos[site_id].copy()

    def _sample_goal(self):
        return self.get_gripper_pose() + self._env.np_random.uniform(-0.05, 0.05, size=3)

    def compute_reward(self, achieved_goal, desired_goal, info):
        d = np.linalg.norm(achieved_goal - desired_goal, axis=-1)
        return -(d > 0.05).astype(np.float32)

    def _is_success(self, achieved_goal, desired_goal):
        return np.linalg.norm(achieved_goal - desired_goal) < 0.05

    def reset(self, **kwargs):
        obs = self._env.reset()
        self.goal = self._sample_goal()
        achieved_goal = self.get_gripper_pose()
        return {
            'observation': obs.copy(),
            'achieved_goal': achieved_goal.copy(),
            'desired_goal': self.goal.copy(),
        }

    def step(self, action):
        for _ in range(self.frame_skip):
            ctrl = self.data.ctrl.copy()
            self.controller.run(action[:6], ctrl)
            ctrl[6] = action[6]
            self._env.do_simulation(ctrl, n_frames=1)
        obs = self._get_obs()
        achieved_goal = self.get_gripper_pose()
        info = {'is_success': self._is_success(achieved_goal, self.goal)}
        return {
            'observation': obs.copy(),
            'achieved_goal': achieved_goal.copy(),
            'desired_goal': self.goal.copy(),
        }, self.compute_reward(achieved_goal, self.goal, info), False, False, info

    def render(self, *args, **kwargs):
        return self._env.render(*args, **kwargs)

    def seed(self, seed=None):
        self._env.seed(seed)
