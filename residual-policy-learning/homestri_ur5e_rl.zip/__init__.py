from gymnasium.envs.registration import register

register(
    id="BaseRobot-v0",
    entry_point="homestri_ur5e_rl.envs.base_robot:BaseRobot",
)

register(
    id="Ur5PickAndPlace-v0",
    entry_point="homestri_ur5e_rl.envs.base_robot:Ur5PickAndPlace",
)