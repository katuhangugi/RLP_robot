import sys
import os
import yaml
import numpy as np
from PyQt5.QtWidgets import QApplication, QMessageBox, QProgressDialog
from PyQt5.QtCore import QThread, pyqtSignal, Qt

# Add the project root to Python path (so src is importable)
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


def check_environment():
    """Check if all required packages are available"""
    try:
        from src.utils.conda_utils import check_environment as check_env
        return check_env()
    except ImportError:
        print("Error: Could not import conda_utils. Please run the setup script.")
        return False


class TrainingThread(QThread):
    """Thread for running training in the background"""
    training_complete = pyqtSignal(str, bool)
    training_progress = pyqtSignal(str)
    
    def __init__(self, env, demonstrations, num_episodes=10):
        super().__init__()
        self.env = env
        self.demonstrations = demonstrations
        self.num_episodes = num_episodes
        self.trainer = None
        
    def run(self):
        try:
            # ✅ Fixed import
            from src.rpl.trainer import RPLTrainer
            
            # Initialize trainer
            policy_config = {
                'input_size': 256,
                'hidden_size': 128,
                'output_size': 10
            }
            
            self.trainer = RPLTrainer(self.env, policy_config)
            self.training_progress.emit("Starting training...")
            
            # Train the policy
            losses, successes = self.trainer.train(
                self.demonstrations, 
                self.num_episodes
            )
            
            # Save the final policy
            self.trainer.save_policy("trained_policies/final_policy.pt")
            
            success_rate = np.mean(successes[-5:]) if len(successes) >= 5 else np.mean(successes)
            self.training_complete.emit(
                f"Training complete! Final success rate: {success_rate:.2%}", 
                True
            )
            
        except Exception as e:
            self.training_complete.emit(f"Training failed: {str(e)}", False)


class NaturalLanguageThread(QThread):
    """Thread for processing natural language commands"""
    command_result = pyqtSignal(str, bool)
    command_progress = pyqtSignal(str)
    
    def __init__(self, env, command, config):
        super().__init__()
        self.env = env
        self.command = command
        self.config = config
        self.demonstration = None
        
    def run(self):
        try:
            self.command_progress.emit(f"Processing command: {self.command}")
            
            # ✅ Fixed imports
            from src.lmp.lmp_core import LMP, LMPFGen
            from src.lmp.prompts import setup_LMP
            
            lmp_processor = setup_LMP(self.env, self.config['lmp'])
            
            # Process the command
            result = lmp_processor(self.command)
            
            # Record the demonstration for training
            self.demonstration = {
                'command': self.command,
                'observation': self.env.get_observation(),
                'action': result if result is not None else {}
            }
            
            self.command_result.emit(
                f"Command executed successfully: {self.command}", 
                True
            )
            
        except Exception as e:
            self.command_result.emit(f"Command failed: {str(e)}", False)
            
    def get_demonstration(self):
        return self.demonstration


def main():
    # Check environment
    if not check_environment():
        print("Environment check failed. Please run: ./setup.sh")
        sys.exit(1)
    
    # Load configuration
    try:
        config_path = os.path.join(PROJECT_ROOT, "src", "config", "config.yaml")
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
    except Exception as e:
        print(f"Error loading config: {e}")
        sys.exit(1)
    
    # Import after path setup
    try:
        from src.ui.main_window import MainWindow
        from src.env.ur5e_env import UR5ePickPlaceEnv
    except ImportError as e:
        print(f"Import error: {e}")
        print("Please make sure all dependencies are installed in the Conda environment.")
        print("Run: conda activate RPL_ur5e && ./setup.sh")
        sys.exit(1)
    
    # Create environment
    env = UR5ePickPlaceEnv(render=True)
    
    # Create application
    app = QApplication(sys.argv)
    
    # Create and show main window
    window = MainWindow(env, config)
    window.show()
    
    # Run application
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
