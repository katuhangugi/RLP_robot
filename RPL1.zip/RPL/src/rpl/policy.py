import torch
import torch.nn as nn
import torch.nn.functional as F


class RPLPolicy(nn.Module):
    def __init__(self, input_size=256, hidden_size=128, output_size=6):
        super(RPLPolicy, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        # Ensure input is the right shape
        if x.dim() == 1:
            x = x.unsqueeze(0)  # Add batch dimension if needed
        
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        
        # Remove batch dimension if it was added
        if x.size(0) == 1:
            x = x.squeeze(0)
            
        return x