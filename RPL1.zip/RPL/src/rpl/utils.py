import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import pybullet as p
import os
import json
from datetime import datetime
import matplotlib.pyplot as plt
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from src.env.utils import get_camera_image


class DemonstrationDataset(Dataset):
    """Dataset for storing and loading demonstrations"""
    
    def __init__(self, demonstrations_dir="trained_policies/demonstrations"):
        self.demonstrations_dir = demonstrations_dir
        self.demonstrations = []
        self.load_demonstrations()
        
    def load_demonstrations(self):
        """Load all demonstrations from the directory"""
        if not os.path.exists(self.demonstrations_dir):
            os.makedirs(self.demonstrations_dir, exist_ok=True)
            return
            
        for file_name in os.listdir(self.demonstrations_dir):
            if file_name.endswith('.json'):
                file_path = os.path.join(self.demonstrations_dir, file_name)
                with open(file_path, 'r') as f:
                    demo = json.load(f)
                    self.demonstrations.append(demo)
    
    def save_demonstration(self, observation, action, command, success):
        """Save a demonstration to file"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_path = os.path.join(self.demonstrations_dir, f"demo_{timestamp}.json")
        
        demonstration = {
            'timestamp': timestamp,
            'observation': observation.tolist() if isinstance(observation, np.ndarray) else observation,
            'action': action.tolist() if isinstance(action, np.ndarray) else action,
            'command': command,
            'success': success
        }
        
        with open(file_path, 'w') as f:
            json.dump(demonstration, f, indent=2)
        
        self.demonstrations.append(demonstration)
        return file_path
    
    def __len__(self):
        return len(self.demonstrations)
    
    def __getitem__(self, idx):
        demo = self.demonstrations[idx]
        
        # Convert to tensors
        observation = torch.tensor(demo['observation'], dtype=torch.float32)
        action = torch.tensor(demo['action'], dtype=torch.float32)
        
        return observation, action

class RPLReplayBuffer:
    """Replay buffer for RPL training"""
    
    def __init__(self, capacity=10000):
        self.capacity = capacity
        self.buffer = []
        self.position = 0
        
    def add(self, observation, action, reward, next_observation, done):
        """Add experience to buffer"""
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.position] = (observation, action, reward, next_observation, done)
        self.position = (self.position + 1) % self.capacity
        
    def sample(self, batch_size):
        """Sample batch of experiences"""
        indices = np.random.randint(0, len(self.buffer), size=batch_size)
        batch = [self.buffer[i] for i in indices]
        
        observations, actions, rewards, next_observations, dones = zip(*batch)
        
        return (
            torch.tensor(observations, dtype=torch.float32),
            torch.tensor(actions, dtype=torch.float32),
            torch.tensor(rewards, dtype=torch.float32),
            torch.tensor(next_observations, dtype=torch.float32),
            torch.tensor(dones, dtype=torch.float32)
        )
    
    def __len__(self):
        return len(self.buffer)

class RPLTrainer:
    """RPL Trainer with improved training utilities"""
    
    def __init__(self, policy, env, config):
        self.policy = policy
        self.env = env
        self.config = config
        
        # Initialize optimizer and loss function
        self.optimizer = optim.Adam(
            self.policy.parameters(), 
            lr=config.get('learning_rate', 0.001),
            weight_decay=config.get('weight_decay', 1e-5)
        )
        
        self.criterion = nn.MSELoss()
        self.replay_buffer = RPLReplayBuffer(config.get('replay_buffer_size', 10000))
        self.demo_dataset = DemonstrationDataset()
        
        # Training statistics
        self.training_losses = []
        self.validation_losses = []
        self.success_rates = []
        
    def collect_demonstration(self, command, max_steps=100):
        """Collect demonstration for a given command"""
        observations = []
        actions = []
        
        # Reset environment
        observation = self.env.reset()
        observations.append(observation)
        
        # Execute command (simplified for demo)
        for step in range(max_steps):
            # Get action from policy or heuristic
            if "blue block" in command and "green bowl" in command:
                action = self._get_pick_place_action("blue block", "green bowl")
            elif "stack" in command and "blocks" in command:
                action = self._get_stack_action()
            else:
                action = np.zeros(6)  # Default action
                
            actions.append(action)
            
            # Execute action
            next_observation, reward, done, _ = self.env.step(action)
            observations.append(next_observation)
            
            if done:
                break
        
        # Save demonstration
        success = self._check_success(command)
        demo_path = self.demo_dataset.save_demonstration(
            np.array(observations), 
            np.array(actions), 
            command, 
            success
        )
        
        return success, demo_path
    
    def _get_pick_place_action(self, obj_name, target_name):
        """Generate pick and place action"""
        # Simplified action generation
        return np.array([0.1, -0.2, 0.05, 0, 0, 1])  # Example action
    
    def _get_stack_action(self):
        """Generate stack action"""
        return np.array([0, -0.3, 0.1, 0, 0, 1])  # Example action
    
    def _check_success(self, command):
        """Check if task was successful"""
        # Simplified success checking
        return True  # Always return True for demo
    
    def train(self, num_epochs=100, batch_size=32, validation_split=0.2):
        """Train the policy using demonstrations"""
        if len(self.demo_dataset) == 0:
            print("No demonstrations available for training.")
            return
        
        # Split into training and validation
        dataset_size = len(self.demo_dataset)
        val_size = int(validation_split * dataset_size)
        train_size = dataset_size - val_size
        
        train_dataset, val_dataset = torch.utils.data.random_split(
            self.demo_dataset, [train_size, val_size]
        )
        
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        
        print(f"Training on {train_size} demonstrations, validating on {val_size}")
        
        for epoch in range(num_epochs):
            # Training phase
            self.policy.train()
            train_loss = 0.0
            
            for observations, actions in train_loader:
                self.optimizer.zero_grad()
                
                # Forward pass
                predicted_actions = self.policy(observations)
                
                # Compute loss
                loss = self.criterion(predicted_actions, actions)
                
                # Backward pass
                loss.backward()
                self.optimizer.step()
                
                train_loss += loss.item()
            
            # Validation phase
            self.policy.eval()
            val_loss = 0.0
            
            with torch.no_grad():
                for observations, actions in val_loader:
                    predicted_actions = self.policy(observations)
                    loss = self.criterion(predicted_actions, actions)
                    val_loss += loss.item()
            
            # Calculate average losses
            avg_train_loss = train_loss / len(train_loader)
            avg_val_loss = val_loss / len(val_loader)
            
            self.training_losses.append(avg_train_loss)
            self.validation_losses.append(avg_val_loss)
            
            # Test policy success rate
            success_rate = self.test_policy()
            self.success_rates.append(success_rate)
            
            print(f"Epoch {epoch+1}/{num_epochs}, "
                  f"Train Loss: {avg_train_loss:.4f}, "
                  f"Val Loss: {avg_val_loss:.4f}, "
                  f"Success Rate: {success_rate:.2f}")
        
        # Save final policy
        self.save_policy("trained_policies/final_policy.pt")
        
        return self.training_losses, self.validation_losses, self.success_rates
    
    def test_policy(self, num_tests=10):
        """Test the policy success rate"""
        self.policy.eval()
        successes = 0
        
        for _ in range(num_tests):
            observation = self.env.reset()
            done = False
            success = False
            
            with torch.no_grad():
                while not done:
                    # Get action from policy
                    observation_tensor = torch.tensor(observation, dtype=torch.float32).unsqueeze(0)
                    action = self.policy(observation_tensor).squeeze(0).numpy()
                    
                    # Execute action
                    observation, reward, done, info = self.env.step(action)
                    
                    if reward > 0:  # Assuming positive reward indicates success
                        success = True
                        break
            
            if success:
                successes += 1
        
        return successes / num_tests
    
    def save_policy(self, path):
        """Save policy to file"""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        torch.save({
            'policy_state_dict': self.policy.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'training_losses': self.training_losses,
            'validation_losses': self.validation_losses,
            'success_rates': self.success_rates,
            'config': self.config
        }, path)
        print(f"Policy saved to {path}")
    
    def load_policy(self, path):
        """Load policy from file"""
        if os.path.exists(path):
            checkpoint = torch.load(path)
            self.policy.load_state_dict(checkpoint['policy_state_dict'])
            self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            self.training_losses = checkpoint.get('training_losses', [])
            self.validation_losses = checkpoint.get('validation_losses', [])
            self.success_rates = checkpoint.get('success_rates', [])
            print(f"Policy loaded from {path}")
            return True
        else:
            print(f"Policy file not found: {path}")
            return False

def create_simple_policy(input_size=256, hidden_size=128, output_size=6):
    """Create a simple neural network policy"""
    return nn.Sequential(
        nn.Linear(input_size, hidden_size),
        nn.ReLU(),
        nn.Dropout(0.2),
        nn.Linear(hidden_size, hidden_size),
        nn.ReLU(),
        nn.Dropout(0.2),
        nn.Linear(hidden_size, output_size)
    )

def preprocess_observation(observation):
    """Preprocess observation for policy input"""
    if 'image' in observation and 'xyzmap' in observation:
        # Flatten image and xyzmap
        image_flat = observation['image'].flatten()
        xyzmap_flat = observation['xyzmap'].flatten()
        
        # Combine features
        features = np.concatenate([image_flat, xyzmap_flat])
        
        # Normalize features
        features = (features - np.mean(features)) / (np.std(features) + 1e-8)
        
        return features
    else:
        # Return zeros if observation format is unexpected
        return np.zeros(256)  # Default input size

def postprocess_action(action, bounds=None):
    """Postprocess action for environment execution"""
    if bounds is None:
        bounds = {
            'position': [-0.3, 0.3, -0.8, -0.2, 0, 0.15],
            'rotation': [0, 2*np.pi]
        }
    
    # Scale action to environment bounds
    if len(action) == 6:  # Assuming [x, y, z, roll, pitch, yaw]
        # Position scaling
        action[0] = np.clip(action[0], bounds['position'][0], bounds['position'][1])
        action[1] = np.clip(action[1], bounds['position'][2], bounds['position'][3])
        action[2] = np.clip(action[2], bounds['position'][4], bounds['position'][5])
        
        # Rotation scaling
        action[3] = action[3] % (2 * np.pi)
        action[4] = action[4] % (2 * np.pi)
        action[5] = action[5] % (2 * np.pi)
    
    return action

def compute_reward(observation, goal_condition):
    """Compute reward based on observation and goal condition"""
    reward = 0
    
    # Simple reward shaping based on object positions
    if 'object_positions' in observation and goal_condition:
        # Check if objects are in desired positions
        for obj_name, target_pos in goal_condition.items():
            if obj_name in observation['object_positions']:
                obj_pos = observation['object_positions'][obj_name]
                distance = np.linalg.norm(np.array(obj_pos) - np.array(target_pos))
                
                # Reward for being close to target
                reward += max(0, 1 - distance / 0.1)  # Max reward when distance < 10cm
    
    return reward

def visualize_training_results(training_losses, validation_losses, success_rates, save_path=None):
    """Visualize training results"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    
    # Plot losses
    ax1.plot(training_losses, label='Training Loss')
    ax1.plot(validation_losses, label='Validation Loss')
    ax1.set_title('Training and Validation Loss')
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('Loss')
    ax1.legend()
    ax1.grid(True)
    
    # Plot success rate
    ax2.plot(success_rates)
    ax2.set_title('Success Rate')
    ax2.set_xlabel('Epoch')
    ax2.set_ylabel('Success Rate')
    ax2.set_ylim(0, 1)
    ax2.grid(True)
    
    plt.tight_layout()
    
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path)
        plt.close()
    else:
        plt.show()

def export_policy_for_deployment(policy, input_size, output_size, export_path):
    """Export policy for deployment in other systems"""
    # Create a traced version of the policy
    dummy_input = torch.randn(1, input_size)
    traced_policy = torch.jit.trace(policy, dummy_input)
    
    # Save traced model
    traced_policy.save(export_path)
    
    # Also save metadata
    metadata = {
        'input_size': input_size,
        'output_size': output_size,
        'export_date': datetime.now().isoformat(),
        'model_type': 'RPLPolicy'
    }
    
    metadata_path = export_path.replace('.pt', '_metadata.json')
    with open(metadata_path, 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print(f"Policy exported to {export_path}")
    print(f"Metadata saved to {metadata_path}")

# Configuration for RPL
DEFAULT_RPL_CONFIG = {
    'learning_rate': 0.001,
    'weight_decay': 1e-5,
    'replay_buffer_size': 10000,
    'batch_size': 32,
    'num_epochs': 100,
    'validation_split': 0.2,
    'input_size': 256,
    'hidden_size': 128,
    'output_size': 6,
    'action_bounds': {
        'position': [-0.3, 0.3, -0.8, -0.2, 0, 0.15],
        'rotation': [0, 2*np.pi]
    }
}

if __name__ == "__main__":
    # Test the utilities
    print("Testing RPL utilities...")
    
    # Test dataset
    dataset = DemonstrationDataset()
    print(f"Loaded {len(dataset)} demonstrations")
    
    # Test policy creation
    policy = create_simple_policy()
    print(f"Created policy with {sum(p.numel() for p in policy.parameters())} parameters")
    
    print("RPL utilities test completed.")