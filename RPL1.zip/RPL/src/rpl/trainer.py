import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
from collections import deque
import json
import yaml
from datetime import datetime
from src.rpl.policy import RPLPolicy
from src.utils.visualization import plot_training_results
import logging

# Set up logging with console output
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('training.log')
    ]
)
logger = logging.getLogger(__name__)

class ReplayBuffer:
    """Experience replay buffer with HER support"""
    def __init__(self, capacity=10000):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)
        self.episode_buffer = []
        logger.info(f"🔄 Replay Buffer initialized with capacity: {capacity}")
        
    def store_transition(self, transition):
        """Store a single transition"""
        # Ensure transition has all required keys
        transition = self._validate_transition(transition)
        self.buffer.append(transition)
        
    def store_episode(self, episode):
        """Store an entire episode and apply HER"""
        # Validate all transitions in the episode
        validated_episode = [self._validate_transition(t) for t in episode]
        self.episode_buffer = validated_episode
        self._apply_her()
        
        for transition in validated_episode:
            self.buffer.append(transition)
            
        self.episode_buffer = []
        logger.info(f"📥 Stored episode with {len(validated_episode)} transitions. Total buffer size: {len(self.buffer)}")
        
    def _validate_transition(self, transition):
        """Ensure transition has all required keys with defaults"""
        if not isinstance(transition, dict):
            transition = {}
            
        # Set default values for missing keys
        defaults = {
            'state': {},
            'action': np.zeros(6),
            'reward': 0.0,
            'next_state': {},
            'done': False,
            'info': {}
        }
        
        validated = {}
        for key in ['state', 'action', 'reward', 'next_state', 'done', 'info']:
            validated[key] = transition.get(key, defaults[key])
            
        return validated
        
    def _apply_her(self):
        """Apply Hindsight Experience Replay"""
        if not self.episode_buffer:
            return
            
        # Get the final achieved goal (last state)
        final_transition = self.episode_buffer[-1]
        final_state = final_transition['next_state'] if 'next_state' in final_transition else final_transition['state']
        achieved_goal = self._extract_achieved_goal(final_state)
        
        for transition in self.episode_buffer:
            new_transition = transition.copy()
            new_transition['desired_goal'] = achieved_goal
            new_transition['reward'] = self._compute_reward(achieved_goal, achieved_goal)
            self.buffer.append(new_transition)
    
    def _extract_achieved_goal(self, state):
        """Extract achieved goal from state"""
        if isinstance(state, dict):
            if 'ee_position' in state:
                return state['ee_position']
            elif 'objects' in state:
                for obj_name, obj_data in state['objects'].items():
                    return obj_data.get('position', [0, 0, 0])
        return np.zeros(3)
    
    def _compute_reward(self, achieved_goal, desired_goal):
        """Compute reward based on goal distance"""
        distance = np.linalg.norm(np.array(achieved_goal) - np.array(desired_goal))
        return -distance
    
    def sample(self, batch_size):
        """Sample a batch of transitions"""
        if len(self.buffer) == 0:
            logger.warning("⚠️  Replay buffer is empty!")
            return None
            
        batch_size = min(batch_size, len(self.buffer))
        indices = np.random.randint(0, len(self.buffer), size=batch_size)
        batch = [self.buffer[i] for i in indices]
        
        try:
            observations, actions, rewards, next_observations, dones = zip(*[
                (t['state'], t['action'], t['reward'], t['next_state'], t['done']) 
                for t in batch
            ])
        except KeyError as e:
            logger.error(f"❌ Missing key in transition: {e}")
            return None
        
        # Convert observations to tensors
        obs_tensors = [self._convert_observation_to_tensor(obs) for obs in observations]
        next_obs_tensors = [self._convert_observation_to_tensor(obs) for obs in next_observations]
        
        obs_tensor = torch.stack(obs_tensors)
        act_tensor = torch.tensor(actions, dtype=torch.float32)
        rew_tensor = torch.tensor(rewards, dtype=torch.float32)
        next_obs_tensor = torch.stack(next_obs_tensors)
        done_tensor = torch.tensor(dones, dtype=torch.float32)
        
        logger.info(f"🎯 Sampled batch: "
                   f"Obs: {obs_tensor.shape}, "
                   f"Act: {act_tensor.shape}, "
                   f"Rew: {rew_tensor.mean().item():.3f}±{rew_tensor.std().item():.3f}, "
                   f"Done: {done_tensor.sum().item()}/{len(done_tensor)}")
        
        return obs_tensor, act_tensor, rew_tensor, next_obs_tensor, done_tensor
    
    def _convert_observation_to_tensor(self, observation):
        """Convert observation to tensor"""
        if not isinstance(observation, dict):
            # If observation is not a dict, create a default one
            observation = {
                'ee_position': [0, 0, 0],
                'objects': {},
                'workspace_bounds': self._get_default_bounds()
            }
        
        flattened = []
        
        # Add end effector position
        ee_pos = observation.get('ee_position', [0, 0, 0])
        flattened.extend(ee_pos)
        
        # Add object positions
        objects = observation.get('objects', {})
        for obj_name, obj_data in objects.items():
            if isinstance(obj_data, dict):
                pos = obj_data.get('position', [0, 0, 0])
                flattened.extend(pos)
                in_workspace = float(obj_data.get('in_workspace', False))
                flattened.append(in_workspace)
        
        # Add workspace bounds
        bounds = observation.get('workspace_bounds', self._get_default_bounds())
        flattened.extend([
            bounds.get('x_min', -0.3), bounds.get('x_max', 0.3),
            bounds.get('y_min', -0.8), bounds.get('y_max', -0.2),
            bounds.get('z_min', 0.0), bounds.get('z_max', 0.15)
        ])
        
        # Pad to expected size
        expected_size = 256
        if len(flattened) < expected_size:
            flattened.extend([0.0] * (expected_size - len(flattened)))
        elif len(flattened) > expected_size:
            flattened = flattened[:expected_size]
        
        return torch.tensor(flattened, dtype=torch.float32)
    
    def _get_default_bounds(self):
        """Get default workspace bounds"""
        return {
            'x_min': -0.3, 'x_max': 0.3,
            'y_min': -0.8, 'y_max': -0.2,
            'z_min': 0.0, 'z_max': 0.15
        }
    
    def __len__(self):
        return len(self.buffer)

class RPLTrainer:
    def __init__(self, env, config=None, log_dir=None):
        self.env = env
        
        # Extract RPL configuration
        self.config = config or {}
        rpl_config = self.config.get('rpl', {})
        
        # Policy configuration
        self.policy_config = {
            'input_size': rpl_config.get('input_size', 256),
            'hidden_size': rpl_config.get('hidden_size', 128),
            'output_size': rpl_config.get('output_size', 6)
        }
        
        # Training configuration
        self.learning_rate = rpl_config.get('learning_rate', 0.001)
        self.batch_size = self.config.get('batch_size', 64)
        self.gamma = self.config.get('gamma', 0.99)
        self.tau = self.config.get('tau', 0.005)
        self.noise_eps = self.config.get('noise_eps', 0.3)
        self.random_eps = self.config.get('random_eps', 0.3)
        self.n_epochs = self.config.get('n_epochs', 100)
        self.n_cycles = self.config.get('n_cycles', 50)
        self.n_batches = self.config.get('n_batches', 40)
        self.n_test_rollouts = self.config.get('n_test_rollouts', 10)
        
        # Initialize policies
        logger.info(f"🧠 Creating RPLPolicy with config: {self.policy_config}")
        self.policy = RPLPolicy(**self.policy_config)
        self.target_policy = RPLPolicy(**self.policy_config)
        self.target_policy.load_state_dict(self.policy.state_dict())
        
        # Count parameters
        total_params = sum(p.numel() for p in self.policy.parameters())
        logger.info(f"📊 Policy parameters: {total_params:,}")
        
        # Optimizer
        self.optimizer = optim.Adam(self.policy.parameters(), lr=self.learning_rate)
        self.criterion = nn.MSELoss()
        
        # Experience replay
        self.replay_buffer = ReplayBuffer(self.config.get('replay_buffer_size', 10000))
        
        # Logging and saving
        self.log_dir = log_dir or f"logs/rpl_trainer_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        os.makedirs(self.log_dir, exist_ok=True)
        self._save_config()
        
        # Training statistics
        self.losses = []
        self.success_rates = []
        self.episode_rewards = []
        
        logger.info("✅ RPLTrainer initialized successfully")
        
    def _save_config(self):
        """Save configuration to file"""
        config_path = os.path.join(self.log_dir, 'config.yaml')
        with open(config_path, 'w') as f:
            yaml.dump(self.config, f, default_flow_style=False)
        logger.info(f"💾 Configuration saved to {config_path}")
        
    def train(self, demonstrations=None):
        """Main training loop"""
        logger.info("🚀 Starting training...")
        logger.info(f"📈 Epochs: {self.n_epochs}, Cycles: {self.n_cycles}, Batches: {self.n_batches}")
        
        if demonstrations:
            for demo in demonstrations:
                self.replay_buffer.store_episode([demo])
        
        best_success_rate = -1
        
        for epoch in range(self.n_epochs):
            epoch_losses = []
            epoch_successes = []
            
            # Training cycles
            for cycle in range(self.n_cycles):
                logger.info(f"🔄 Epoch {epoch+1}/{self.n_epochs}, Cycle {cycle+1}/{self.n_cycles}")
                
                # Generate rollout
                episode = self.generate_rollout(explore=True)
                if episode:
                    self.replay_buffer.store_episode(episode)
                
                # Train on batches
                for batch_idx in range(self.n_batches):
                    if len(self.replay_buffer) > self.batch_size:
                        loss = self.train_batch()
                        if loss is not None:
                            epoch_losses.append(loss)
                            
                        if batch_idx % 10 == 0 and loss is not None:
                            logger.info(f"   📚 Batch {batch_idx+1}/{self.n_batches}, Loss: {loss:.4f}")
                
                # Update target network
                self.update_target_network()
            
            # Test the policy
            test_success_rate = self.test_policy(self.n_test_rollouts)
            epoch_successes.append(test_success_rate)
            
            # Log statistics
            avg_loss = np.mean(epoch_losses) if epoch_losses else 0
            avg_success = np.mean(epoch_successes) if epoch_successes else 0
            
            self.losses.append(avg_loss)
            self.success_rates.append(avg_success)
            
            logger.info(f"🎯 Epoch {epoch+1} Results: "
                       f"Loss: {avg_loss:.4f}, "
                       f"Success Rate: {avg_success:.3f}")
            
            # Save best policy
            if avg_success > best_success_rate:
                best_success_rate = avg_success
                self.save_policy(os.path.join(self.log_dir, "policy_best.pt"))
                logger.info(f"🏆 New best success rate: {best_success_rate:.3f}")
            
            # Save periodic policy
            if (epoch + 1) % 10 == 0:
                self.save_policy(os.path.join(self.log_dir, f"policy_epoch_{epoch+1}.pt"))
            
            # Save training statistics
            self.save_training_stats()
        
        # Plot results
        plot_training_results(self.losses, self.success_rates)
        
        logger.info("🎉 Training completed!")
        if self.success_rates:
            logger.info(f"📊 Final success rate: {self.success_rates[-1]:.3f}")
        if self.losses:
            logger.info(f"📉 Final loss: {self.losses[-1]:.4f}")
        
        return self.losses, self.success_rates
    
    def generate_rollout(self, explore=False, render=False):
        """Generate a rollout (episode)"""
        episode = []
        try:
            state = self.env.reset()
        except:
            state = self._get_default_state()
            
        done = False
        total_reward = 0
        
        logger.info("🎬 Generating rollout...")
        
        while not done:
            # Select action
            if explore and random.random() < self.random_eps:
                action = self._get_random_action()
                logger.debug("   🎲 Random action")
            else:
                action = self.select_action(state, explore=explore)
                logger.debug("   🤖 Policy action")
            
            try:
                # Execute action
                next_state, reward, done, info = self.env.step(action)
            except:
                # If step fails, use default values
                next_state = self._get_default_state()
                reward = 0.0
                done = True
                info = {}
            
            # Store transition with proper next_state
            transition = {
                'state': state,
                'action': action,
                'reward': reward,
                'next_state': next_state,  # Ensure next_state is included
                'done': done,
                'info': info
            }
            episode.append(transition)
            
            total_reward += reward
            state = next_state
            
            if render:
                try:
                    self.env.render()
                except:
                    pass
        
        self.episode_rewards.append(total_reward)
        logger.info(f"   ✅ Rollout completed: {len(episode)} steps, Total reward: {total_reward:.2f}")
        
        return episode
    
    def _get_default_state(self):
        """Get default state if environment fails"""
        return {
            'ee_position': [0, 0, 0],
            'objects': {},
            'workspace_bounds': {
                'x_min': -0.3, 'x_max': 0.3,
                'y_min': -0.8, 'y_max': -0.2,
                'z_min': 0.0, 'z_max': 0.15
            }
        }
    
    def _get_random_action(self):
        """Get random action"""
        return np.random.uniform(-1, 1, 6)
    
    def select_action(self, state, explore=False):
        """Select action using policy"""
        state_tensor = self._convert_observation_to_tensor(state)
        
        with torch.no_grad():
            action = self.policy(state_tensor).numpy()
        
        if explore:
            # Add exploration noise
            noise = self.noise_eps * np.random.normal(size=action.shape)
            action = action + noise
            action = np.clip(action, -1, 1)
            logger.debug(f"   🔊 Added exploration noise")
        
        return action
    
    def train_batch(self):
        """Train on a batch of experiences"""
        self.policy.train()
        self.optimizer.zero_grad()
        
        batch = self.replay_buffer.sample(self.batch_size)
        if batch is None:
            return None
            
        obs_tensor, act_tensor, rew_tensor, next_obs_tensor, done_tensor = batch
        
        total_loss = 0
        
        # Current Q value
        current_q = self.policy(obs_tensor)
        current_action_q = torch.sum(current_q * act_tensor, dim=1)
        
        # Target Q value
        with torch.no_grad():
            next_q = self.target_policy(next_obs_tensor)
            max_next_q, _ = torch.max(next_q, dim=1)
            target_q = rew_tensor + self.gamma * max_next_q * (1 - done_tensor)
        
        # Compute loss
        loss = self.criterion(current_action_q, target_q)
        total_loss = loss.item()
        
        # Backward pass
        loss.backward()
        self.optimizer.step()
        
        return total_loss
    
    def update_target_network(self):
        """Soft update of target network"""
        for target_param, param in zip(self.target_policy.parameters(), self.policy.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
        logger.debug("🔄 Target network updated")
    
    def test_policy(self, n_rollouts=10):
        """Test the current policy"""
        logger.info(f"🧪 Testing policy with {n_rollouts} rollouts...")
        
        successes = 0
        
        for i in range(n_rollouts):
            episode = self.generate_rollout(explore=False, render=False)
            if episode and self._is_episode_successful(episode):
                successes += 1
                logger.info(f"   ✅ Rollout {i+1}: Success")
            else:
                logger.info(f"   ❌ Rollout {i+1}: Failure")
        
        success_rate = successes / n_rollouts if n_rollouts > 0 else 0
        logger.info(f"📊 Test results: {successes}/{n_rollouts} successful ({success_rate:.3f})")
        
        return success_rate
    
    def _is_episode_successful(self, episode):
        """Check if episode was successful"""
        if not episode:
            return False
            
        last_transition = episode[-1]
        last_reward = last_transition.get('reward', 0)
        return last_reward > 0
    
    def _convert_observation_to_tensor(self, observation):
        """Convert observation to tensor"""
        if not isinstance(observation, dict):
            observation = self._get_default_state()
        
        flattened = []
        
        # Add end effector position
        ee_pos = observation.get('ee_position', [0, 0, 0])
        flattened.extend(ee_pos)
        
        # Add object positions
        for obj_name, obj_data in observation.get('objects', {}).items():
            if isinstance(obj_data, dict):
                pos = obj_data.get('position', [0, 0, 0])
                flattened.extend(pos)
                in_workspace = float(obj_data.get('in_workspace', False))
                flattened.append(in_workspace)
        
        # Add workspace bounds
        bounds = observation.get('workspace_bounds', {})
        flattened.extend([bounds.get('x_min', -0.3), bounds.get('x_max', 0.3),
                         bounds.get('y_min', -0.8), bounds.get('y_max', -0.2),
                         bounds.get('z_min', 0.0), bounds.get('z_max', 0.15)])
        
        # Pad to expected size
        expected_size = self.policy_config['input_size']
        if len(flattened) < expected_size:
            flattened.extend([0.0] * (expected_size - len(flattened)))
        elif len(flattened) > expected_size:
            flattened = flattened[:expected_size]
        
        return torch.tensor(flattened, dtype=torch.float32)
    
    def save_policy(self, path):
        """Save policy to file"""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        torch.save({
            'policy_state_dict': self.policy.state_dict(),
            'target_policy_state_dict': self.target_policy.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'policy_config': self.policy_config,
            'trainer_config': self.config
        }, path)
        logger.info(f"💾 Policy saved to {path}")
    
    def load_policy(self, path):
        """Load policy from file"""
        if os.path.exists(path):
            checkpoint = torch.load(path)
            self.policy.load_state_dict(checkpoint['policy_state_dict'])
            self.target_policy.load_state_dict(checkpoint['target_policy_state_dict'])
            self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            self.policy_config = checkpoint.get('policy_config', self.policy_config)
            self.config = checkpoint.get('trainer_config', self.config)
            logger.info(f"📂 Policy loaded from {path}")
            return True
        else:
            logger.error(f"❌ Policy file not found: {path}")
            return False
    
    def save_training_stats(self):
        """Save training statistics"""
        stats = {
            'losses': self.losses,
            'success_rates': self.success_rates,
            'episode_rewards': self.episode_rewards,
            'policy_config': self.policy_config,
            'trainer_config': self.config
        }
        
        stats_path = os.path.join(self.log_dir, 'training_stats.json')
        with open(stats_path, 'w') as f:
            json.dump(stats, f, indent=2)
        logger.info(f"💾 Training statistics saved to {stats_path}")

# Utility function for launching training
def launch_training(env, config_path=None, log_dir=None, **kwargs):
    """Launch training with configuration"""
    
    # Load config from YAML file if provided
    config = {}
    if config_path and os.path.exists(config_path):
        try:
            with open(config_path, 'r') as f:
                if config_path.endswith('.yaml') or config_path.endswith('.yml'):
                    config = yaml.safe_load(f)
                else:
                    config = json.load(f)
            logger.info(f"📄 Loaded configuration from {config_path}")
        except Exception as e:
            logger.warning(f"⚠️ Failed to load config file: {e}")
    
    # Override with kwargs
    config.update(kwargs)
    
    # Ensure rpl section exists
    if 'rpl' not in config:
        config['rpl'] = {}
    
    # Update rpl section with kwargs that belong there
    rpl_keys = ['input_size', 'hidden_size', 'output_size', 'learning_rate']
    for key in rpl_keys:
        if key in kwargs:
            config['rpl'][key] = kwargs[key]
    
    # Create trainer
    trainer = RPLTrainer(env, config, log_dir)
    
    # Start training
    losses, successes = trainer.train()
    
    return trainer, losses, successes

if __name__ == "__main__":
    # Example usage
    import argparse
    
    parser = argparse.ArgumentParser(description='RPL Training')
    parser.add_argument('--env', type=str, default='Ur5PickAndPlace-v0', help='Environment name')
    parser.add_argument('--config', type=str, default=None, help='Config file path')
    parser.add_argument('--logdir', type=str, default=None, help='Log directory')
    parser.add_argument('--epochs', type=int, default=100, help='Number of epochs')
    parser.add_argument('--learning_rate', type=float, default=0.001, help='Learning rate')
    
    args = parser.parse_args()
    
    # Create a dummy environment for testing
    class DummyEnv:
        def reset(self):
            return {
                'ee_position': [0, 0, 0],
                'objects': {
                    'blue block': {'position': [0.1, -0.6, 0.02], 'in_workspace': True},
                    'red bowl': {'position': [-0.1, -0.4, 0.0], 'in_workspace': True}
                },
                'workspace_bounds': {
                    'x_min': -0.3, 'x_max': 0.3,
                    'y_min': -0.8, 'y_max': -0.2,
                    'z_min': 0.0, 'z_max': 0.15
                }
            }
            
        def step(self, action):
            next_state = self.reset()
            reward = 1.0 if np.random.random() > 0.5 else 0.0
            done = False
            info = {}
            return next_state, reward, done, info
            
        def render(self):
            pass
    
    env = DummyEnv()
    
    logger.info("🤖 Starting RPL Training...")
    logger.info("=" * 50)
    
    trainer, losses, successes = launch_training(
        env=env,
        config_path=args.config,
        log_dir=args.logdir,
        n_epochs=args.epochs,
        learning_rate=args.learning_rate
    )
    
    logger.info("=" * 50)
    if successes:
        logger.info(f"🎉 Training completed! Final success rate: {successes[-1]:.3f}")
    else:
        logger.info("❌ Training completed with no success data")