import sys
import os
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QMessageBox, QSplitter, QSizePolicy, QApplication)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QDesktopServices
from PyQt5.QtCore import QUrl
from .robot_view import RobotViewWidget
from .control_panel import ControlPanel
from rpl.trainer import RPLTrainer
import threading

class TrainingThread(QThread):
    progress_updated = pyqtSignal(float, str)
    training_completed = pyqtSignal(bool, str)
    
    def __init__(self, trainer, training_data):
        super().__init__()
        self.trainer = trainer
        self.training_data = training_data
    
    def run(self):
        try:
            self.progress_updated.emit(0.1, "Preparing training data...")
            
            # Convert training data to format suitable for RPL
            demonstrations = []
            for example in self.training_data:
                if example['successful']:
                    demonstrations.append({
                        'observation': example['state'],
                        'action': example['action']
                    })
            
            self.progress_updated.emit(0.3, f"Training with {len(demonstrations)} examples...")
            
            # Train the policy
            losses, successes = self.trainer.train(demonstrations)
            
            # Create training progress video
            if hasattr(self.trainer, 'training_history') and self.trainer.training_history:
                from utils.video_recorder import VideoRecorder
                video_recorder = VideoRecorder()
                progress_video_path = video_recorder.create_training_progress_video(
                    self.trainer.training_history
                )
                if progress_video_path:
                    self.progress_updated.emit(0.9, f"Created training progress video: {os.path.basename(progress_video_path)}")
            
            self.progress_updated.emit(1.0, "Training completed successfully!")
            self.training_completed.emit(True, f"Training completed with {sum(successes)}/{len(successes)} successful episodes")
            
        except Exception as e:
            self.progress_updated.emit(0.0, f"Training failed: {str(e)}")
            self.training_completed.emit(False, f"Training failed: {str(e)}")

class MainWindow(QMainWindow):
    def __init__(self, env, config):
        super().__init__()
        self.env = env
        self.config = config
        
        # Get screen dimensions
        screen = QApplication.primaryScreen()
        screen_geometry = screen.availableGeometry()
        screen_width = screen_geometry.width()
        screen_height = screen_geometry.height()
        
        # Set window size to 90% of screen
        self.resize(int(screen_width * 0.9), int(screen_height * 0.9))
        
        # Center the window
        self.move(int(screen_width * 0.05), int(screen_height * 0.05))
        
        self.setWindowTitle("UR5e Robot Control with Natural Language")
        
        self.training_data = []
        self.trainer = None
        self.training_thread = None
        
        self.init_ui()
        self.setup_connections()
        
    def init_ui(self):
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(5, 5, 5, 5)
        main_layout.setSpacing(5)
        
        # Use a splitter for resizable panels
        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.setHandleWidth(5)
        splitter.setStyleSheet("""
            QSplitter::handle:horizontal {
                background: #cccccc;
                width: 2px;
                margin: 0px;
            }
            QSplitter::handle:horizontal:hover {
                background: #aaaaaa;
            }
        """)
        
        # Left side - Robot view
        self.robot_view = RobotViewWidget()
        self.robot_view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        splitter.addWidget(self.robot_view)
        
        # Right side - Control panel
        self.control_panel = ControlPanel()
        self.control_panel.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        splitter.addWidget(self.control_panel)
        
        # Set initial sizes (70% for robot view, 30% for control panel)
        splitter.setSizes([int(self.width() * 0.7), int(self.width() * 0.3)])
        
        main_layout.addWidget(splitter)
        
    def setup_connections(self):
        # Connect control panel signals to robot view
        self.control_panel.command_submitted.connect(self.robot_view.execute_command)
        self.control_panel.reset_simulation.connect(self.robot_view.reset_simulation)
        self.control_panel.start_training.connect(self.start_training)
        self.control_panel.start_recording.connect(self.start_recording)
        self.control_panel.stop_recording.connect(self.stop_recording)
        
        # Connect robot view signals to control panel
        self.robot_view.frame_updated.connect(self.control_panel.update_video_frame)
        self.robot_view.command_executed.connect(self.control_panel.update_status)
        self.robot_view.training_data_generated.connect(self.control_panel.add_training_data)
        self.robot_view.training_data_generated.connect(self.add_training_data)
        self.robot_view.recording_status_changed.connect(self.control_panel.update_recording_status)
        
        # Connect control panel links to open files
        self.control_panel.status_display.anchorClicked.connect(self.open_file_from_link)
        
    def open_file_from_link(self, url):
        """Open file from clicked link in status display"""
        file_path = url.toString().replace('file://', '')
        if os.path.exists(file_path):
            QDesktopServices.openUrl(QUrl.fromLocalFile(file_path))
        
    def add_training_data(self, data):
        """Add training data to collection"""
        self.training_data.append(data)
        
    def start_recording(self, video_name=None):
        """Start video recording"""
        success = self.robot_view.start_recording(video_name)
        if not success:
            QMessageBox.warning(self, "Recording Error", "Failed to start recording. Check if another recording is in progress.")
        
    def stop_recording(self):
        """Stop video recording"""
        video_path = self.robot_view.stop_recording()
        if video_path:
            self.control_panel.show_video_saved_message(video_path)
        
    def start_training(self):
        """Start training with collected data"""
        if not self.training_data:
            self.control_panel.update_status("Training", "No training data available")
            QMessageBox.information(self, "Training", "No training data available. Please execute some commands first.")
            return
        
        # Initialize trainer
        from rpl.trainer import RPLTrainer
        
        policy_config = {
            'input_size': 256,
            'hidden_size': 128,
            'output_size': 6
        }
        
        self.trainer = RPLTrainer(self.robot_view.env, policy_config)
        
        # Start training in separate thread
        self.training_thread = TrainingThread(self.trainer, self.training_data)
        self.training_thread.progress_updated.connect(self.control_panel.update_training_progress)
        self.training_thread.training_completed.connect(self.training_completed)
        self.training_thread.start()
        
        # Record training session
        self.start_recording("training_session.mp4")
        
    def training_completed(self, success, message):
        """Handle training completion"""
        self.control_panel.update_status("Training", message)
        
        # Stop training recording
        video_path = self.stop_recording()
        
        if success:
            # Save the trained policy
            try:
                os.makedirs("trained_policies", exist_ok=True)
                policy_path = "trained_policies/trained_policy.pt"
                self.trainer.save_policy(policy_path)
                self.control_panel.update_status("Training", f"Policy saved to {policy_path}")
                
                # Show success message
                QMessageBox.information(self, "Training Complete", 
                                      f"Training completed successfully!\n\n"
                                      f"Policy saved to: {policy_path}\n"
                                      f"Training video: {os.path.basename(video_path) if video_path else 'Not available'}")
            except Exception as e:
                self.control_panel.update_status("Training", f"Failed to save policy: {e}")
                QMessageBox.warning(self, "Training Error", f"Failed to save policy: {e}")
        
    def closeEvent(self, event):
        # Stop recording if active
        if self.robot_view.is_recording():
            self.robot_view.stop_recording()
            
        self.robot_view.cleanup()
        
        # Stop training thread if running
        if self.training_thread and self.training_thread.isRunning():
            self.training_thread.terminate()
            self.training_thread.wait()
            
        event.accept()