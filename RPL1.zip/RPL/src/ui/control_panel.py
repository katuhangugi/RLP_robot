from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QTextBrowser,
                             QLineEdit, QPushButton, QLabel, QGroupBox,
                             QComboBox, QSlider, QSpinBox, QCheckBox, QProgressBar,
                             QFileDialog, QMessageBox, QSizePolicy, QScrollArea, QFrame)
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QPixmap, QFont, QColor, QPalette
import json
import os
from datetime import datetime

class ControlPanel(QWidget):
    command_submitted = pyqtSignal(str)
    reset_simulation = pyqtSignal()
    start_training = pyqtSignal()
    start_recording = pyqtSignal(str)
    stop_recording = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.training_data = []
        self.init_ui()
        self.apply_styles()
        
    def apply_styles(self):
        """Apply better styling to the UI"""
        # Set font
        font = QFont("Arial", 9)
        self.setFont(font)
        
        # Set background color
        palette = self.palette()
        palette.setColor(QPalette.Window, QColor(240, 240, 240))
        self.setPalette(palette)
        
    def init_ui(self):
        # Create scroll area for the control panel
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.NoFrame)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        
        # Main container widget
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(8)
        layout.setContentsMargins(8, 8, 8, 8)
        
        # Video display
        video_group = QGroupBox("Live View")
        video_group.setCheckable(True)
        video_group.setChecked(True)
        video_group.setStyleSheet("QGroupBox { font-weight: bold; }")
        video_layout = QVBoxLayout()
        
        self.video_label = QLabel()
        self.video_label.setMinimumSize(240, 180)  # Smaller minimum size
        self.video_label.setMaximumHeight(300)     # Limit maximum height
        self.video_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.video_label.setStyleSheet("""
            border: 2px solid #cccccc; 
            background-color: #000000;
            border-radius: 5px;
        """)
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setText("Camera Feed")
        
        video_layout.addWidget(self.video_label)
        video_group.setLayout(video_layout)
        
        # Command input
        command_group = QGroupBox("Natural Language Command")
        command_group.setCheckable(True)
        command_group.setChecked(True)
        command_group.setStyleSheet("QGroupBox { font-weight: bold; }")
        command_layout = QVBoxLayout()
        
        self.command_input = QLineEdit()
        self.command_input.setPlaceholderText("Enter command (e.g., 'pick the blue block and place it on the green bowl')")
        self.command_input.setStyleSheet("""
            QLineEdit {
                padding: 5px;
                border: 1px solid #cccccc;
                border-radius: 3px;
                background-color: white;
            }
            QLineEdit:focus {
                border: 2px solid #0078d7;
            }
        """)
        self.command_input.returnPressed.connect(self.submit_command)
        
        self.submit_btn = QPushButton("Execute Command")
        self.submit_btn.setStyleSheet("""
            QPushButton {
                background-color: #0078d7;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #106ebe;
            }
            QPushButton:pressed {
                background-color: #005a9e;
            }
        """)
        self.submit_btn.clicked.connect(self.submit_command)
        
        command_layout.addWidget(QLabel("Enter command:"))
        command_layout.addWidget(self.command_input)
        command_layout.addWidget(self.submit_btn)
        command_group.setLayout(command_layout)
        
        # Status display
        status_group = QGroupBox("Status")
        status_group.setCheckable(True)
        status_group.setChecked(True)
        status_group.setStyleSheet("QGroupBox { font-weight: bold; }")
        status_layout = QVBoxLayout()
        
        self.status_display = QTextBrowser()
        self.status_display.setReadOnly(True)
        self.status_display.setOpenExternalLinks(True)
        self.status_display.setMinimumHeight(120)
        self.status_display.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.status_display.setStyleSheet("""
            QTextBrowser {
                background-color: white;
                border: 1px solid #cccccc;
                border-radius: 3px;
                padding: 5px;
            }
        """)
        
        status_layout.addWidget(self.status_display)
        status_group.setLayout(status_layout)
        
        # Video recording controls
        recording_group = QGroupBox("Video Recording")
        recording_group.setCheckable(True)
        recording_group.setChecked(False)  # Collapsed by default
        recording_group.setStyleSheet("QGroupBox { font-weight: bold; }")
        recording_layout = QVBoxLayout()
        
        self.record_btn = QPushButton("Start Recording")
        self.record_btn.setStyleSheet("""
            QPushButton {
                background-color: #d13438;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #b02a30;
            }
        """)
        self.record_btn.clicked.connect(self.toggle_recording)
        self.recording = False
        
        self.custom_name_check = QCheckBox("Custom video name")
        self.custom_name_check.stateChanged.connect(self.toggle_custom_name)
        
        self.video_name_input = QLineEdit()
        self.video_name_input.setPlaceholderText("Enter custom video name")
        self.video_name_input.setEnabled(False)
        self.video_name_input.setStyleSheet("""
            QLineEdit {
                padding: 5px;
                border: 1px solid #cccccc;
                border-radius: 3px;
                background-color: white;
            }
        """)
        
        recording_layout.addWidget(self.record_btn)
        recording_layout.addWidget(self.custom_name_check)
        recording_layout.addWidget(self.video_name_input)
        recording_group.setLayout(recording_layout)
        
        # Control buttons
        control_group = QGroupBox("Controls")
        control_group.setCheckable(True)
        control_group.setChecked(True)
        control_group.setStyleSheet("QGroupBox { font-weight: bold; }")
        control_layout = QVBoxLayout()
        
        self.reset_btn = QPushButton("Reset Simulation")
        self.reset_btn.setStyleSheet("""
            QPushButton {
                background-color: #107c10;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #0e6b0e;
            }
        """)
        self.reset_btn.clicked.connect(self.reset_simulation.emit)
        
        self.train_btn = QPushButton("Start Training")
        self.train_btn.setStyleSheet("""
            QPushButton {
                background-color: #8661c5;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #7556b2;
            }
        """)
        self.train_btn.clicked.connect(self.start_training.emit)
        
        self.save_data_btn = QPushButton("Save Training Data")
        self.save_data_btn.setStyleSheet("""
            QPushButton {
                background-color: #505050;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #404040;
            }
        """)
        self.save_data_btn.clicked.connect(self.save_training_data)
        
        control_layout.addWidget(self.reset_btn)
        control_layout.addWidget(self.train_btn)
        control_layout.addWidget(self.save_data_btn)
        control_group.setLayout(control_layout)
        
        # Training progress
        training_group = QGroupBox("Training Progress")
        training_group.setCheckable(True)
        training_group.setChecked(False)  # Collapsed by default
        training_group.setStyleSheet("QGroupBox { font-weight: bold; }")
        training_layout = QVBoxLayout()
        
        self.training_progress = QProgressBar()
        self.training_progress.setValue(0)
        self.training_progress.setStyleSheet("""
            QProgressBar {
                border: 1px solid #cccccc;
                border-radius: 3px;
                text-align: center;
                background-color: #f0f0f0;
            }
            QProgressBar::chunk {
                background-color: #0078d7;
                width: 10px;
            }
        """)
        
        self.training_status = QLabel("Not started")
        
        training_layout.addWidget(QLabel("Training Progress:"))
        training_layout.addWidget(self.training_progress)
        training_layout.addWidget(self.training_status)
        training_group.setLayout(training_layout)
        
        # Object selection
        object_group = QGroupBox("Scene Objects")
        object_group.setCheckable(True)
        object_group.setChecked(False)  # Collapsed by default
        object_group.setStyleSheet("QGroupBox { font-weight: bold; }")
        object_layout = QVBoxLayout()
        
        self.object_combo = QComboBox()
        self.object_combo.addItems(["blue block", "red block", "green block", 
                                   "blue bowl", "red bowl", "green bowl"])
        self.object_combo.setStyleSheet("""
            QComboBox {
                padding: 5px;
                border: 1px solid #cccccc;
                border-radius: 3px;
                background-color: white;
            }
        """)
        
        object_layout.addWidget(QLabel("Available objects:"))
        object_layout.addWidget(self.object_combo)
        object_group.setLayout(object_layout)
        
        # Workspace information
        workspace_group = QGroupBox("Workspace Information")
        workspace_group.setCheckable(True)
        workspace_group.setChecked(False)  # Collapsed by default
        workspace_group.setStyleSheet("QGroupBox { font-weight: bold; }")
        workspace_layout = QVBoxLayout()

        workspace_info = QLabel(
            "Workspace Bounds:\n"
            "X: [-0.3, 0.3]\n"
            "Y: [-0.8, -0.2]\n"
            "Z: [0, 0.15]\n"
            "All objects should be within red wireframe"
        )
        workspace_info.setStyleSheet("""
            QLabel {
                background-color: #f8f8f8;
                border: 1px solid #cccccc;
                border-radius: 3px;
                padding: 5px;
            }
        """)

        workspace_layout.addWidget(workspace_info)
        workspace_group.setLayout(workspace_layout)
        
        # Add all groups to main layout with stretch factors
        layout.addWidget(video_group)
        layout.addWidget(command_group)
        layout.addWidget(status_group)
        layout.addWidget(recording_group)
        layout.addWidget(control_group)
        layout.addWidget(training_group)
        layout.addWidget(object_group)
        layout.addWidget(workspace_group)
        
        # Add stretch at the end to push everything up
        layout.addStretch(1)
        
        # Set scroll area widget
        scroll_area.setWidget(container)
        
        # Set main layout for the control panel
        main_layout = QVBoxLayout(self)
        main_layout.addWidget(scroll_area)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Connect group toggling to adjust sizes
        groups = [video_group, command_group, status_group, recording_group, 
                 control_group, training_group, object_group, workspace_group]
        for group in groups:
            group.toggled.connect(self.adjust_layout)
            
    def adjust_layout(self):
        """Adjust layout when groups are collapsed/expanded"""
        self.updateGeometry()
            
    def submit_command(self):
        command = self.command_input.text().strip()
        if command:
            self.command_submitted.emit(command)
            self.status_display.append(f"> {command}")
            self.command_input.clear()
            
    def toggle_recording(self):
        if not self.recording:
            # Start recording
            video_name = None
            if self.custom_name_check.isChecked() and self.video_name_input.text().strip():
                video_name = self.video_name_input.text().strip()
                if not video_name.endswith('.mp4'):
                    video_name += '.mp4'
            
            self.start_recording.emit(video_name)
        else:
            # Stop recording
            self.stop_recording.emit()
            
    def toggle_custom_name(self, state):
        self.video_name_input.setEnabled(state == Qt.Checked)
        
    def update_recording_status(self, recording, message):
        """Update recording status"""
        self.recording = recording
        if recording:
            self.record_btn.setText("Stop Recording")
            self.record_btn.setStyleSheet("""
                QPushButton {
                    background-color: #ff4444;
                    color: white;
                    border: none;
                    padding: 8px;
                    border-radius: 4px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #d13438;
                }
            """)
        else:
            self.record_btn.setText("Start Recording")
            self.record_btn.setStyleSheet("""
                QPushButton {
                    background-color: #d13438;
                    color: white;
                    border: none;
                    padding: 8px;
                    border-radius: 4px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #b02a30;
                }
            """)
        
        self.status_display.append(f"📹 {message}")
            
    def update_status(self, command, success):
        if success:
            self.status_display.append(f"<span style='color: green;'>✓ Successfully executed: {command}</span>")
        else:
            self.status_display.append(f"<span style='color: red;'>✗ Failed to execute: {command}</span>")
            
    def update_video_frame(self, pixmap):
        self.video_label.setPixmap(pixmap.scaled(
            self.video_label.width(), 
            self.video_label.height(),
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation
        ))
    
    def add_training_data(self, data):
        """Add training data to collection"""
        self.training_data.append(data)
        self.status_display.append(f"<span style='color: blue;'>✓ Added training example #{len(self.training_data)}</span>")
    
    def save_training_data(self):
        """Save training data to file"""
        if not self.training_data:
            self.status_display.append("<span style='color: orange;'>No training data to save</span>")
            return
        
        try:
            # Open file dialog to choose save location
            file_path, _ = QFileDialog.getSaveFileName(
                self, "Save Training Data", "training_data.json", "JSON Files (*.json)"
            )
            
            if file_path:
                with open(file_path, 'w') as f:
                    json.dump(self.training_data, f, indent=2)
                
                self.status_display.append(f"<span style='color: green;'>✓ Saved {len(self.training_data)} training examples to {file_path}</span>")
                self.training_data = []  # Clear after saving
                
        except Exception as e:
            self.status_display.append(f"<span style='color: red;'>✗ Failed to save training data: {e}</span>")
    
    def update_training_progress(self, progress, status):
        """Update training progress bar and status"""
        self.training_progress.setValue(int(progress * 100))
        self.training_status.setText(status)
        
    def show_video_saved_message(self, video_path):
        """Show message when video is saved"""
        if video_path and os.path.exists(video_path):
            # Create a clickable message to open the video
            message = f"📹 Video saved: <a href='/home/ngugi/Documents/RPL/videos' style='color: #0078d7; text-decoration: none;'>{os.path.basename(video_path)}</a>"
            self.status_display.append(message)