import pybullet as p
import pybullet_data
import numpy as np
from PyQt5.QtWidgets import QOpenGLWidget, QSizePolicy
from PyQt5.QtCore import QTimer, pyqtSignal
from PyQt5.QtGui import QImage, QPixmap
import threading
import time
import cv2
from datetime import datetime
import os
import sys

class RobotViewWidget(QOpenGLWidget):
    frame_updated = pyqtSignal(QPixmap)
    command_executed = pyqtSignal(str, bool)
    training_data_generated = pyqtSignal(dict)
    recording_status_changed = pyqtSignal(bool, str)
    
    def __init__(self):
        super().__init__()
        self.setMinimumSize(400, 300)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.physics_client = None
        self.env = None
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.is_simulating = False
        self.recording = False
        self.video_recorder = None
        self.current_command = ""
        self._initialized = False
        self._initialization_attempted = False
        
        # Camera configuration
        self.camera_config = {
            'width': 640,
            'height': 480,
            'fov': 60,
            'near': 0.02,
            'far': 1000,
            'camera_eye_pos': [1.2, -0.5, 0.8],
            'camera_target_pos': [0, -0.5, 0.2],
            'camera_up_vector': [0, 0, 1]
        }
        
    def initializeGL(self):
        if self._initialization_attempted:
            return
            
        self._initialization_attempted = True
        
        try:
            print("Initializing Robot Environment...")
            self.initialize_environment()
            self._initialized = True
            print("Robot Environment initialized successfully")
            
        except Exception as e:
            print(f"Failed to initialize Robot Environment: {e}")
            import traceback
            traceback.print_exc()
            self._initialized = False
        
    def initialize_environment(self):
        """Initialize the robot environment step by step"""
        
        # Step 1: Connect to PyBullet
        try:
            print("Step 1: Connecting to PyBullet...")
            self.physics_client = p.connect(p.DIRECT)  # Use DIRECT mode for stability
            p.setAdditionalSearchPath(pybullet_data.getDataPath())
            p.setGravity(0, 0, -9.8)
            print("PyBullet connected successfully")
        except Exception as e:
            raise Exception(f"Failed to connect to PyBullet: {e}")
        
        # Step 2: Load the environment
        try:
            print("Step 2: Loading UR5e environment...")
            self.load_environment()
            print("Environment loaded successfully")
        except Exception as e:
            raise Exception(f"Failed to load environment: {e}")
        
        # Step 3: Initialize video recorder (optional)
        try:
            print("Step 3: Initializing video recorder...")
            self.initialize_video_recorder()
            print("Video recorder initialized")
        except Exception as e:
            print(f"Video recorder initialization failed (non-critical): {e}")
            self.video_recorder = None
        
        # Step 4: Start simulation
        print("Step 4: Starting simulation...")
        self.is_simulating = True
        self.timer.start(16)  # 60 FPS
        
    def load_environment(self):
        """Load the UR5e environment"""
        
        # Get the correct path for the environment module
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Try multiple possible paths for the environment
        possible_paths = [
            os.path.join(current_dir, "..", "env"),
            os.path.join(current_dir, "..", "..", "src", "env"),
            os.path.join(current_dir, "env"),
            current_dir
        ]
        
        env_module_found = False
        for path in possible_paths:
            if path not in sys.path:
                sys.path.insert(0, path)
            
            try:
                if os.path.exists(os.path.join(path, "ur5e_env.py")):
                    from ur5e_env import UR5ePickPlaceEnv
                    env_module_found = True
                    print(f"Found environment module at: {path}")
                    break
            except ImportError:
                continue
        
        if not env_module_found:
            # Create a simple fallback environment
            print("Creating fallback environment...")
            self.env = self.create_fallback_environment()
            return
        
        # Get assets path
        assets_paths = [
            os.path.join(current_dir, "..", "..", "assets"),
            os.path.join(current_dir, "..", "assets"),
            os.path.join(current_dir, "assets"),
            os.path.join(os.path.expanduser("~"), "ur5e_assets")
        ]
        
        assets_path = None
        for path in assets_paths:
            if os.path.exists(path):
                assets_path = os.path.abspath(path)
                print(f"Found assets at: {assets_path}")
                break
        
        if not assets_path:
            print("Assets not found, creating fallback environment...")
            self.env = self.create_fallback_environment()
            return
        
        # Create the environment
        try:
            self.env = UR5ePickPlaceEnv(
                render=False,
                assets_path=assets_path,
                physics_client=self.physics_client
            )
            print("UR5e environment created successfully")
        except Exception as e:
            print(f"Failed to create UR5e environment: {e}")
            print("Creating fallback environment...")
            self.env = self.create_fallback_environment()
    
    def create_fallback_environment(self):
        """Create a simple fallback environment when assets are missing"""
        
        class FallbackEnvironment:
            def __init__(self, physics_client):
                self.physics_client = physics_client
                self.objects = {}
                self.workspace_bounds = {
                    'x_min': -0.3, 'x_max': 0.3,
                    'y_min': -0.8, 'y_max': -0.2,
                    'z_min': 0.0, 'z_max': 0.15
                }
                self.setup_simple_scene()
                
            def setup_simple_scene(self):
                """Create a simple scene with basic objects"""
                print("Setting up simple fallback scene...")
                
                # Create ground plane
                plane_id = p.createCollisionShape(p.GEOM_PLANE)
                p.createMultiBody(0, plane_id)
                
                # Create simple objects
                colors = {
                    'blue': [0.3, 0.3, 1.0, 1],
                    'red': [1.0, 0.3, 0.3, 1], 
                    'green': [0.3, 1.0, 0.3, 1]
                }
                
                # Create blocks
                for i, (color, rgba) in enumerate(colors.items()):
                    pos = [-0.2 + i * 0.2, -0.6, 0.025]
                    box_shape = p.createCollisionShape(p.GEOM_BOX, halfExtents=[0.025, 0.025, 0.025])
                    box_visual = p.createVisualShape(p.GEOM_BOX, halfExtents=[0.025, 0.025, 0.025], rgbaColor=rgba)
                    box_id = p.createMultiBody(0.1, box_shape, box_visual, basePosition=pos)
                    self.objects[f'{color} block'] = box_id
                
                # Create bowls (as cylinders)
                for i, (color, rgba) in enumerate(colors.items()):
                    pos = [-0.2 + i * 0.2, -0.4, 0.01]
                    cyl_shape = p.createCollisionShape(p.GEOM_CYLINDER, radius=0.04, height=0.02)
                    cyl_visual = p.createVisualShape(p.GEOM_CYLINDER, radius=0.04, length=0.02, rgbaColor=rgba)
                    cyl_id = p.createMultiBody(0.1, cyl_shape, cyl_visual, basePosition=pos)
                    self.objects[f'{color} bowl'] = cyl_id
                
                print(f"Created {len(self.objects)} objects: {list(self.objects.keys())}")
            
            def execute_command(self, command):
                """Execute command with simple object manipulation"""
                print(f"Fallback environment executing: {command}")
                command = command.lower()
                
                try:
                    if "pick" in command and ("place" in command or "put" in command):
                        return self.execute_pick_place(command)
                    elif "move" in command:
                        return self.execute_move(command)
                    elif "stack" in command:
                        return self.execute_stack()
                    else:
                        print(f"Command '{command}' not implemented in fallback environment")
                        return False
                except Exception as e:
                    print(f"Error executing command: {e}")
                    return False
            
            def execute_pick_place(self, command):
                """Simple pick and place"""
                # Parse command to find object and target
                words = command.split()
                obj_name = None
                target_name = None
                
                # Find object to pick
                for i, word in enumerate(words):
                    if word == "pick" and i + 2 < len(words):
                        if words[i+1] == "the":
                            obj_name = f"{words[i+2]} {words[i+3]}" if i+3 < len(words) else None
                        else:
                            obj_name = f"{words[i+1]} {words[i+2]}" if i+2 < len(words) else None
                        break
                
                # Find target
                for i, word in enumerate(words):
                    if word in ["on", "in", "into"] and i + 1 < len(words):
                        if words[i+1] == "the" and i + 3 < len(words):
                            target_name = f"{words[i+2]} {words[i+3]}"
                        elif i + 2 < len(words):
                            target_name = f"{words[i+1]} {words[i+2]}"
                        break
                
                if not obj_name or not target_name:
                    print(f"Could not parse command. Object: {obj_name}, Target: {target_name}")
                    return False
                
                if obj_name not in self.objects:
                    print(f"Object '{obj_name}' not found. Available: {list(self.objects.keys())}")
                    return False
                
                if target_name not in self.objects:
                    print(f"Target '{target_name}' not found. Available: {list(self.objects.keys())}")
                    return False
                
                # Move object to target position
                target_pos, _ = p.getBasePositionAndOrientation(self.objects[target_name])
                new_pos = [target_pos[0], target_pos[1], target_pos[2] + 0.05]
                p.resetBasePositionAndOrientation(self.objects[obj_name], new_pos, [0, 0, 0, 1])
                
                print(f"Moved {obj_name} to {target_name}")
                return True
            
            def execute_move(self, command):
                """Simple move command"""
                words = command.split()
                obj_name = None
                
                # Find object to move
                for i, word in enumerate(words):
                    if word == "move" and i + 2 < len(words):
                        if words[i+1] == "the":
                            obj_name = f"{words[i+2]} {words[i+3]}" if i+3 < len(words) else None
                        break
                
                if not obj_name or obj_name not in self.objects:
                    print(f"Could not find object to move: {obj_name}")
                    return False
                
                # Move to center by default
                center_pos = [0, -0.5, 0.05]
                p.resetBasePositionAndOrientation(self.objects[obj_name], center_pos, [0, 0, 0, 1])
                print(f"Moved {obj_name} to center")
                return True
            
            def execute_stack(self):
                """Stack all blocks"""
                blocks = [name for name in self.objects.keys() if 'block' in name]
                if not blocks:
                    return False
                
                base_pos = [0, -0.5, 0.025]
                for i, block_name in enumerate(blocks):
                    stack_pos = [base_pos[0], base_pos[1], base_pos[2] + i * 0.05]
                    p.resetBasePositionAndOrientation(self.objects[block_name], stack_pos, [0, 0, 0, 1])
                
                print(f"Stacked {len(blocks)} blocks")
                return True
            
            def get_state(self):
                """Get current state"""
                state = {'objects': {}, 'workspace_bounds': self.workspace_bounds}
                for name, obj_id in self.objects.items():
                    pos, orient = p.getBasePositionAndOrientation(obj_id)
                    state['objects'][name] = {
                        'position': pos,
                        'orientation': orient,
                        'in_workspace': True
                    }
                return state
            
            def get_last_action(self):
                """Get last action"""
                return {'type': 'fallback_action', 'timestamp': datetime.now().isoformat()}
            
            def reset(self):
                """Reset environment"""
                self.setup_simple_scene()
                return self.get_state()
            
            def step_sim_and_render(self):
                """Step simulation"""
                p.stepSimulation()
            
            def get_camera_image(self):
                """Get camera image"""
                try:
                    view_matrix = p.computeViewMatrixFromYawPitchRoll(
                        cameraTargetPosition=[0, -0.5, 0],
                        distance=1.5, yaw=90, pitch=-30, roll=0, upAxisIndex=2
                    )
                    projection_matrix = p.computeProjectionMatrixFOV(
                        fov=60, aspect=640/480, nearVal=0.1, farVal=100.0
                    )
                    
                    _, _, rgb, _, _ = p.getCameraImage(
                        width=640, height=480,
                        viewMatrix=view_matrix,
                        projectionMatrix=projection_matrix,
                        renderer=p.ER_BULLET_HARDWARE_OPENGL
                    )
                    
                    return np.reshape(rgb, (480, 640, 4))[:, :, :3]
                except:
                    return self.create_placeholder_image()
            
            def cleanup(self):
                """Cleanup"""
                pass
        
        return FallbackEnvironment(self.physics_client)
    
    def initialize_video_recorder(self):
        """Initialize video recorder if available"""
        try:
            # Create a simple video recorder class if not available
            class SimpleVideoRecorder:
                def __init__(self):
                    self.recording = False
                    self.frames = []
                
                def start_recording(self, name=None):
                    self.recording = True
                    self.frames = []
                    return f"recording_{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp4"
                
                def stop_recording(self):
                    self.recording = False
                    path = f"video_{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp4"
                    print(f"Video would be saved as: {path}")
                    return path
                
                def add_frame(self, frame):
                    if self.recording:
                        self.frames.append(frame)
                
                def is_recording(self):
                    return self.recording
            
            self.video_recorder = SimpleVideoRecorder()
            
        except Exception as e:
            print(f"Failed to initialize video recorder: {e}")
            self.video_recorder = None
    
    def get_camera_image(self):
        """Get camera image from environment or create placeholder"""
        try:
            if self.env and hasattr(self.env, 'get_camera_image'):
                return self.env.get_camera_image()
            else:
                return self.create_placeholder_image()
        except Exception as e:
            print(f"Error getting camera image: {e}")
            return self.create_placeholder_image()
    
    def create_placeholder_image(self):
        """Create a placeholder image when camera is not available"""
        placeholder = np.zeros((480, 640, 3), dtype=np.uint8)
        placeholder[:] = [40, 40, 40]  # Dark gray background
        
        # Add grid pattern
        for i in range(0, 640, 50):
            cv2.line(placeholder, (i, 0), (i, 480), (60, 60, 60), 1)
        for i in range(0, 480, 50):
            cv2.line(placeholder, (0, i), (640, i), (60, 60, 60), 1)
        
        # Add text
        cv2.putText(placeholder, "UR5e Robot Simulation", (150, 200), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        
        if self._initialized:
            cv2.putText(placeholder, "Environment: Active", (200, 250), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        else:
            cv2.putText(placeholder, "Environment: Initializing...", (150, 250), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 0), 2)
        
        cv2.putText(placeholder, "Camera feed will appear here", (120, 300), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 200), 1)
        
        return placeholder
            
    def execute_command(self, command):
        """Execute command in the robot environment"""
        self.current_command = command
        
        def run_command():
            try:
                success = False
                
                if not self._initialized:
                    error_msg = "Environment not initialized. Attempting to initialize..."
                    print(error_msg)
                    self.command_executed.emit(error_msg, False)
                    
                    # Try to initialize again
                    try:
                        self.initialize_environment()
                        if self._initialized:
                            self.command_executed.emit("Environment initialized successfully", True)
                        else:
                            self.command_executed.emit("Failed to initialize environment", False)
                            self.current_command = ""
                            return
                    except Exception as e:
                        error_msg = f"Initialization failed: {str(e)}"
                        self.command_executed.emit(error_msg, False)
                        self.current_command = ""
                        return
                
                if not self.env:
                    error_msg = "Environment object is None"
                    print(error_msg)
                    self.command_executed.emit(error_msg, False)
                    self.current_command = ""
                    return
                
                print(f"Executing command: {command}")
                
                # Execute the command
                success = self.env.execute_command(command)
                
                # Generate training data if successful
                if success:
                    training_data = self.generate_training_data(command, success)
                    self.training_data_generated.emit(training_data)
                
                # Emit result
                if success:
                    self.command_executed.emit(command, True)
                else:
                    self.command_executed.emit(f"Failed to execute: {command}", False)
                
                # Clear current command after delay
                time.sleep(1)
                self.current_command = ""
                
            except Exception as e:
                error_msg = f"Error executing command: {str(e)}"
                print(error_msg)
                import traceback
                traceback.print_exc()
                self.command_executed.emit(error_msg, False)
                self.current_command = ""
                
        thread = threading.Thread(target=run_command)
        thread.daemon = True
        thread.start()
        
    def generate_training_data(self, command, successful=True):
        """Generate training data from command execution"""
        try:
            state = self.env.get_state() if hasattr(self.env, 'get_state') else {}
            action = self.env.get_last_action() if hasattr(self.env, 'get_last_action') else {}
            
            example = {
                'command': command,
                'state': state,
                'action': action,
                'successful': successful,
                'timestamp': datetime.now().isoformat()
            }
            
            return example
        except Exception as e:
            print(f"Error generating training data: {e}")
            return {
                'command': command,
                'state': {},
                'action': {},
                'successful': successful,
                'timestamp': datetime.now().isoformat()
            }
    
    def start_recording(self, video_name=None):
        """Start video recording"""
        if not self.video_recorder:
            self.recording_status_changed.emit(False, "Video recorder not available")
            return False
            
        try:
            video_path = self.video_recorder.start_recording(video_name)
            self.recording = True
            self.recording_status_changed.emit(True, f"Recording started: {os.path.basename(video_path)}")
            return True
        except Exception as e:
            print(f"Failed to start recording: {e}")
            self.recording_status_changed.emit(False, f"Recording failed: {e}")
            return False
            
    def stop_recording(self):
        """Stop video recording"""
        if not self.video_recorder or not self.recording:
            return None
            
        try:
            video_path = self.video_recorder.stop_recording()
            self.recording = False
            self.recording_status_changed.emit(False, f"Recording saved: {os.path.basename(video_path)}")
            return video_path
        except Exception as e:
            print(f"Failed to stop recording: {e}")
            self.recording_status_changed.emit(False, f"Recording stop failed: {e}")
            return None
        
    def is_recording(self):
        """Check if currently recording"""
        return self.recording and self.video_recorder and self.video_recorder.is_recording()
        
    def reset_simulation(self):
        """Reset the simulation environment"""
        if self.env and hasattr(self.env, 'reset'):
            try:
                self.env.reset()
                print("Simulation reset successfully")
                self.current_command = ""
            except Exception as e:
                print(f"Error resetting simulation: {e}")
        else:
            print("Cannot reset: environment not available")
    
    def paintGL(self):
        """Render the scene"""
        if not self._initialized:
            return
            
        try:
            # Get camera image
            image = self.get_camera_image()
            
            # Add overlays
            if self.recording and self.video_recorder:
                # Recording indicator
                cv2.circle(image, (30, 30), 10, (0, 0, 255), -1)
                cv2.putText(image, "REC", (50, 35), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
                
                # Timestamp
                timestamp = datetime.now().strftime("%H:%M:%S")
                cv2.putText(image, timestamp, (10, image.shape[0] - 20), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            
            # Current command overlay
            if self.current_command:
                overlay = image.copy()
                cv2.rectangle(overlay, (10, 50), (image.shape[1] - 10, 90), (0, 0, 0), -1)
                image = cv2.addWeighted(overlay, 0.7, image, 0.3, 0)
                
                display_command = self.current_command
                if len(display_command) > 70:
                    display_command = display_command[:67] + "..."
                    
                cv2.putText(image, f"Executing: {display_command}", (15, 70), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            
            # Convert BGR to RGB for Qt
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
            # Convert to QPixmap and emit signal
            height, width, channel = image_rgb.shape
            bytes_per_line = 3 * width
            q_img = QImage(image_rgb.data, width, height, bytes_per_line, QImage.Format_RGB888)
            pixmap = QPixmap.fromImage(q_img)
            self.frame_updated.emit(pixmap)
            
            # Add frame to video recording if active
            if self.recording and self.video_recorder:
                self.video_recorder.add_frame(image_rgb)
                    
        except Exception as e:
            print(f"Error in paintGL: {e}")
    
    def update_frame(self):
        """Update frame - called by timer"""
        if self.is_simulating and self._initialized and self.env:
            try:
                # Step the simulation
                if hasattr(self.env, 'step_sim_and_render'):
                    self.env.step_sim_and_render()
                else:
                    p.stepSimulation()
                
                # Update the display
                self.update()
            except Exception as e:
                print(f"Error in update_frame: {e}")
                
    def cleanup(self):
        """Cleanup resources"""
        print("Cleaning up robot view...")
        
        # Stop recording if active
        if self.recording:
            self.stop_recording()
            
        # Stop the timer
        if self.timer.isActive():
            self.timer.stop()
            
        # Cleanup environment
        if self.env and hasattr(self.env, 'cleanup'):
            try:
                self.env.cleanup()
            except Exception as e:
                print(f"Error cleaning up environment: {e}")
            
        # Disconnect from physics server
        if self.physics_client is not None:
            try:
                p.disconnect(self.physics_client)
                print("Physics client disconnected")
            except Exception as e:
                print(f"Error disconnecting from physics server: {e}")
            self.physics_client = None