import numpy as np
import pybullet as p

# Global constants
COLORS = {
    'blue': (78/255, 121/255, 167/255, 1),
    'red': (255/255, 87/255, 89/255, 1),
    'green': (89/255, 169/255, 79/255, 1),
    'orange': (242/255, 142/255, 43/255, 1),
    'yellow': (237/255, 201/255, 72/255, 1),
}

def get_camera_image(width=640, height=480):
    """Get camera image from simulation"""
    view_matrix = p.computeViewMatrixFromYawPitchRoll(
        cameraTargetPosition=[0, -0.5, 0],
        distance=1.5,
        yaw=90,
        pitch=-30,
        roll=0,
        upAxisIndex=2
    )
    projection_matrix = p.computeProjectionMatrixFOV(
        fov=60, aspect=width/height, nearVal=0.1, farVal=100.0
    )
    
    _, _, rgb, _, _ = p.getCameraImage(
        width=width, height=height,
        viewMatrix=view_matrix,
        projectionMatrix=projection_matrix,
        renderer=p.ER_BULLET_HARDWARE_OPENGL
    )
    
    return np.reshape(rgb, (height, width, 4))[:, :, :3]  # Remove alpha channel

def create_object(obj_type, color, position):
    """Create an object in the simulation"""
    if obj_type == "block":
        shape = p.createCollisionShape(p.GEOM_BOX, halfExtents=[0.02, 0.02, 0.02])
        visual = p.createVisualShape(p.GEOM_BOX, halfExtents=[0.02, 0.02, 0.02])
        obj_id = p.createMultiBody(0.01, shape, visual, basePosition=position)
    elif obj_type == "bowl":
        obj_id = p.loadURDF("/home/ngugi/Documents/RPL/assets/bowl/bowl/bowl.urdf", position, useFixedBase=1)
    
    p.changeVisualShape(obj_id, -1, rgbaColor=COLORS[color])
    return obj_id