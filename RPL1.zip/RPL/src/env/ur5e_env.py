import pybullet as p
import pybullet_data
import numpy as np
import os
import threading
import time
from collections import deque

class UR5ePickPlaceEnv:
    def __init__(self, render=False, assets_path="../assets"):
        self.render = render
        self.assets_path = assets_path
        self.robot_urdf_path = os.path.join(assets_path, "ur5e", "ur5e", "ur5e.urdf")
        self.gripper_urdf_path = os.path.join(assets_path, "robotiq_2f_85", "robotiq_2f_85", "robotiq_2f_85.urdf")
        self.bowl_urdf_path = os.path.join(assets_path, "bowl", "bowl", "bowl.urdf")
        self.home_joints = (np.pi / 2, -np.pi / 2, np.pi / 2, -np.pi / 2, 3 * np.pi / 2, 0)
        self.ee_link_id = 9  # End effector link ID
        self.tip_link_id = 10  # Tool tip link ID
        self.joint_ids = None
        self.objects = {}
        self.last_action = None
        self.action_history = deque(maxlen=100)
        
        # Workspace boundaries (aligned with the black square)
        self.workspace_bounds = {
            'x_min': -0.3,
            'x_max': 0.3,
            'y_min': -0.8,
            'y_max': -0.2,
            'z_min': 0.0,
            'z_max': 0.15
        }
        
        self.setup_simulation()
        
    def setup_simulation(self):
        # Connect to PyBullet
        if self.render:
            self.physics_client = p.connect(p.GUI)
            p.configureDebugVisualizer(p.COV_ENABLE_GUI, 0)  # Disable PyBullet GUI
        else:
            self.physics_client = p.connect(p.DIRECT)
            
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        p.setGravity(0, 0, -9.8)
        
        # Load UR5e robot
        self.robot_id = p.loadURDF(self.robot_urdf_path, [0, 0, 0])
        
        # Get joint information
        self.joint_ids = []
        for i in range(p.getNumJoints(self.robot_id)):
            joint_info = p.getJointInfo(self.robot_id, i)
            if joint_info[2] == p.JOINT_REVOLUTE:
                self.joint_ids.append(joint_info[0])
        
        # Move to home position
        self.move_to_home()
        
        # Load other assets
        self.load_assets()
        
    def load_assets(self):
        # Load Robotiq gripper
        gripper_pos = [0.1339999999999999, -0.49199999999872496, 0.5]
        gripper_rot = p.getQuaternionFromEuler([np.pi, 0, np.pi])
        
        # Check if gripper URDF exists
        if not os.path.exists(self.gripper_urdf_path):
            raise FileNotFoundError(f"Gripper URDF not found at: {self.gripper_urdf_path}")
            
        self.gripper_id = p.loadURDF(self.gripper_urdf_path, gripper_pos, gripper_rot)
        
        # Create constraint between robot and gripper
        p.createConstraint(self.robot_id, self.ee_link_id, self.gripper_id, 0, 
                          p.JOINT_FIXED, [0, 0, 0], [0, 0, 0], [0, 0, -0.07])
        
        # Load workspace (black square)
        plane_shape = p.createCollisionShape(p.GEOM_BOX, halfExtents=[0.3, 0.3, 0.001])
        plane_visual = p.createVisualShape(p.GEOM_BOX, halfExtents=[0.3, 0.3, 0.001])
        self.plane_id = p.createMultiBody(0, plane_shape, plane_visual, basePosition=[0, -0.5, 0])
        p.changeVisualShape(self.plane_id, -1, rgbaColor=[0.2, 0.2, 0.2, 1.0])
        
        # Load objects within workspace bounds
        self.load_objects()
        
    def load_objects(self):
        # Create some blocks and bowls within workspace bounds
        colors = {
            'blue': (78/255, 121/255, 167/255, 1),
            'red': (255/255, 87/255, 89/255, 1),
            'green': (89/255, 169/255, 79/255, 1),
        }
        
        # Calculate positions within workspace bounds
        x_min, x_max = self.workspace_bounds['x_min'], self.workspace_bounds['x_max']
        y_min, y_max = self.workspace_bounds['y_min'], self.workspace_bounds['y_max']
        
        # Create blocks within workspace
        block_positions = [
            [x_min + 0.1, y_min + 0.1, 0.025],  # Bottom left
            [0, y_min + 0.1, 0.025],            # Bottom center
            [x_max - 0.1, y_min + 0.1, 0.025],  # Bottom right
        ]
        
        for i, (color, block_pos) in enumerate(zip(colors.keys(), block_positions)):
            block_shape = p.createCollisionShape(p.GEOM_BOX, halfExtents=[0.02, 0.02, 0.02])
            block_visual = p.createVisualShape(p.GEOM_BOX, halfExtents=[0.02, 0.02, 0.02])
            block_id = p.createMultiBody(0.01, block_shape, block_visual, basePosition=block_pos)
            p.changeVisualShape(block_id, -1, rgbaColor=colors[color])
            self.objects[f'{color} block'] = block_id
        
        # Create bowls within workspace
        bowl_positions = [
            [x_min + 0.1, y_max - 0.1, 0],  # Top left
            [0, y_max - 0.1, 0],            # Top center
            [x_max - 0.1, y_max - 0.1, 0],  # Top right
        ]
        
        for i, (color, bowl_pos) in enumerate(zip(colors.keys(), bowl_positions)):
            # Check if bowl URDF exists
            if not os.path.exists(self.bowl_urdf_path):
                print(f"Bowl URDF not found at: {self.bowl_urdf_path}, using primitive shape instead")
                # Create a bowl-like shape using primitive
                bowl_shape = p.createCollisionShape(p.GEOM_CYLINDER, radius=0.05, height=0.02)
                bowl_visual = p.createVisualShape(p.GEOM_CYLINDER, radius=0.05, length=0.02, rgbaColor=colors[color])
                bowl_id = p.createMultiBody(0.1, bowl_shape, bowl_visual, basePosition=bowl_pos)
            else:
                bowl_id = p.loadURDF(self.bowl_urdf_path, bowl_pos, useFixedBase=1)
                p.changeVisualShape(bowl_id, -1, rgbaColor=colors[color])
                
            self.objects[f'{color} bowl'] = bowl_id
            
        print(f"Loaded {len(self.objects)} objects within workspace bounds")
    
    def move_to_home(self):
        """Move robot to home position"""
        for i, joint_id in enumerate(self.joint_ids):
            p.resetJointState(self.robot_id, joint_id, self.home_joints[i])
    
    def get_ee_position(self):
        """Get end effector position"""
        return p.getLinkState(self.robot_id, self.tip_link_id)[0]
    
    def is_within_workspace(self, position):
        """Check if position is within workspace bounds"""
        x, y, z = position
        return (self.workspace_bounds['x_min'] <= x <= self.workspace_bounds['x_max'] and
                self.workspace_bounds['y_min'] <= y <= self.workspace_bounds['y_max'] and
                self.workspace_bounds['z_min'] <= z <= self.workspace_bounds['z_max'])
    
    def move_arm_to_position(self, target_position, speed=0.05):
        """Move arm to target position using inverse kinematics"""
        # Ensure target is within workspace
        if not self.is_within_workspace(target_position):
            print(f"Warning: Target position {target_position} is outside workspace bounds")
            # Clamp to workspace bounds
            target_position = [
                np.clip(target_position[0], self.workspace_bounds['x_min'], self.workspace_bounds['x_max']),
                np.clip(target_position[1], self.workspace_bounds['y_min'], self.workspace_bounds['y_max']),
                np.clip(target_position[2], self.workspace_bounds['z_min'], self.workspace_bounds['z_max'])
            ]
            print(f"Clamped to: {target_position}")
        
        current_pos = self.get_ee_position()
        distance = np.linalg.norm(np.array(target_position) - np.array(current_pos))
        
        # Calculate number of steps based on distance and speed
        num_steps = max(int(distance / speed), 1)
        
        # Generate trajectory
        trajectory = np.linspace(current_pos, target_position, num_steps)
        
        for point in trajectory:
            # Ensure each point is within workspace
            if not self.is_within_workspace(point):
                point = [
                    np.clip(point[0], self.workspace_bounds['x_min'], self.workspace_bounds['x_max']),
                    np.clip(point[1], self.workspace_bounds['y_min'], self.workspace_bounds['y_max']),
                    np.clip(point[2], self.workspace_bounds['z_min'], self.workspace_bounds['z_max'])
                ]
            
            # Calculate inverse kinematics
            joint_angles = p.calculateInverseKinematics(
                self.robot_id, self.tip_link_id, point,
                targetOrientation=p.getQuaternionFromEuler([np.pi, 0, np.pi]),
                maxNumIterations=100
            )
            
            # Move joints
            for i, joint_id in enumerate(self.joint_ids):
                p.setJointMotorControl2(
                    self.robot_id, joint_id, p.POSITION_CONTROL,
                    targetPosition=joint_angles[i],
                    force=500,
                    positionGain=0.1
                )
            
            # Step simulation
            p.stepSimulation()
            if self.render:
                time.sleep(1/240)
        
        self.last_action = {
            'type': 'move_arm',
            'target_position': target_position,
            'trajectory': trajectory
        }
        self.action_history.append(self.last_action)
    
    def pick_object(self, object_name):
        """Pick up an object"""
        if object_name not in self.objects:
            print(f"Object '{object_name}' not found")
            return False
        
        object_id = self.objects[object_name]
        object_pos, _ = p.getBasePositionAndOrientation(object_id)
        
        # Ensure object is within workspace
        if not self.is_within_workspace(object_pos):
            print(f"Object '{object_name}' is outside workspace at {object_pos}")
            return False
        
        # Move above object
        approach_pos = [object_pos[0], object_pos[1], object_pos[2] + 0.1]
        self.move_arm_to_position(approach_pos)
        
        # Move to object
        self.move_arm_to_position(object_pos)
        
        # Close gripper (simulated by moving object with robot)
        # In a real implementation, you'd control the gripper here
        
        # Lift object
        lift_pos = [object_pos[0], object_pos[1], object_pos[2] + 0.2]
        self.move_arm_to_position(lift_pos)
        
        self.last_action = {
            'type': 'pick_object',
            'object_name': object_name,
            'object_position': object_pos
        }
        self.action_history.append(self.last_action)
        
        return True
    
    def place_object(self, target_position):
        """Place object at target position"""
        # Ensure target is within workspace
        if not self.is_within_workspace(target_position):
            print(f"Target position {target_position} is outside workspace bounds")
            return False
        
        # Move to target position
        self.move_arm_to_position(target_position)
        
        # Open gripper (simulated)
        # In a real implementation, you'd control the gripper here
        
        # Move up
        up_pos = [target_position[0], target_position[1], target_position[2] + 0.1]
        self.move_arm_to_position(up_pos)
        
        self.last_action = {
            'type': 'place_object',
            'target_position': target_position
        }
        self.action_history.append(self.last_action)
        
        return True
    
    def execute_command(self, command):
        """Execute a natural language command"""
        # Simple command parsing
        command = command.lower()
        
        if "pick" in command and "place" in command:
            # Extract object and target from command
            parts = command.split()
            object_name = None
            target_name = None
            
            for i, part in enumerate(parts):
                if part == "pick":
                    object_name = f"{parts[i+1]} {parts[i+2]}"
                elif part == "place" and "on" in parts[i+1:]:
                    target_idx = parts.index("on", i) + 1
                    target_name = f"{parts[target_idx]} {parts[target_idx+1]}"
            
            if object_name and target_name and object_name in self.objects and target_name in self.objects:
                # Get target position
                target_pos, _ = p.getBasePositionAndOrientation(self.objects[target_name])
                
                # Pick and place
                success = self.pick_object(object_name)
                if success:
                    success = self.place_object(target_pos)
                
                return success
        
        elif "stack" in command and "blocks" in command:
            # Stack all blocks in the center of workspace
            block_names = [name for name in self.objects.keys() if "block" in name]
            base_pos = [0, -0.5, 0.025]  # Center of workspace
            
            for i, block_name in enumerate(block_names):
                stack_pos = [base_pos[0], base_pos[1], base_pos[2] + i * 0.05]
                self.pick_object(block_name)
                self.place_object(stack_pos)
            
            return True
        
        elif "move" in command and "to" in command:
            # Move specific object to position
            parts = command.split()
            object_name = None
            position_name = None
            
            for i, part in enumerate(parts):
                if part == "move":
                    object_name = f"{parts[i+1]} {parts[i+2]}"
                elif part == "to":
                    position_name = " ".join(parts[i+1:i+4])
            
            if object_name and object_name in self.objects:
                # Map position names to coordinates
                position_map = {
                    "center": [0, -0.5, 0.025],
                    "top left": [self.workspace_bounds['x_min'] + 0.1, self.workspace_bounds['y_max'] - 0.1, 0.025],
                    "top right": [self.workspace_bounds['x_max'] - 0.1, self.workspace_bounds['y_max'] - 0.1, 0.025],
                    "bottom left": [self.workspace_bounds['x_min'] + 0.1, self.workspace_bounds['y_min'] + 0.1, 0.025],
                    "bottom right": [self.workspace_bounds['x_max'] - 0.1, self.workspace_bounds['y_min'] + 0.1, 0.025],
                }
                
                if position_name in position_map:
                    target_pos = position_map[position_name]
                    success = self.pick_object(object_name)
                    if success:
                        success = self.place_object(target_pos)
                    return success
        
        return False
    
    def get_state(self):
        """Get current environment state"""
        state = {
            'ee_position': self.get_ee_position(),
            'objects': {},
            'workspace_bounds': self.workspace_bounds
        }
        
        for name, obj_id in self.objects.items():
            pos, orient = p.getBasePositionAndOrientation(obj_id)
            state['objects'][name] = {
                'position': pos,
                'orientation': orient,
                'in_workspace': self.is_within_workspace(pos)
            }
        
        return state
    
    def get_last_action(self):
        """Get last executed action"""
        return self.last_action
    
    def reset(self, object_list=None):
        """Reset simulation"""
        p.resetSimulation()
        p.setGravity(0, 0, -9.8)
        
        # Reload assets
        self.setup_simulation()
        
        return self.get_state()
    
    def step_sim_and_render(self):
        """Step simulation and render"""
        p.stepSimulation()
        if self.render:
            time.sleep(1/240)
    
    def get_camera_image(self):
        """Get camera image for display"""
        width, height = 640, 480
        view_matrix = p.computeViewMatrixFromYawPitchRoll(
            cameraTargetPosition=[0, -0.5, 0],  # Center of workspace
            distance=1.5,
            yaw=90,
            pitch=-30,
            roll=0,
            upAxisIndex=2
        )
        projection_matrix = p.computeProjectionMatrixFOV(
            fov=60, aspect=width/height, nearVal=0.1, farVal=100.0
        )
        
        _, _, rgb, _, _ = p.getCameraImage(
            width=width, height=height,
            viewMatrix=view_matrix,
            projectionMatrix=projection_matrix,
            renderer=p.ER_BULLET_HARDWARE_OPENGL
        )
        
        return np.reshape(rgb, (height, width, 4))[:, :, :3]  # Remove alpha channel
    
    def cleanup(self):
        """Clean up simulation"""
        if hasattr(self, 'physics_client'):
            p.disconnect(self.physics_client)