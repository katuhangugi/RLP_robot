import matplotlib.pyplot as plt
import numpy as np
import os
import json
from datetime import datetime

def plot_training_results(losses, successes, save_path="results"):
    """Plot training loss and success rate"""
    os.makedirs(save_path, exist_ok=True)
    
    # Create figure with two subplots
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    
    # Plot loss
    ax1.plot(losses, 'b-', linewidth=2)
    ax1.set_title('Training Loss', fontsize=14, fontweight='bold')
    ax1.set_xlabel('Episode', fontsize=12)
    ax1.set_ylabel('Loss', fontsize=12)
    ax1.grid(True, alpha=0.3)
    ax1.tick_params(axis='both', which='major', labelsize=10)
    
    # Plot success rate
    success_rate = np.cumsum(successes) / (np.arange(len(successes)) + 1)
    ax2.plot(success_rate, 'g-', linewidth=2)
    ax2.set_title('Success Rate', fontsize=14, fontweight='bold')
    ax2.set_xlabel('Episode', fontsize=12)
    ax2.set_ylabel('Success Rate', fontsize=12)
    ax2.grid(True, alpha=0.3)
    ax2.set_ylim(0, 1)
    ax2.tick_params(axis='both', which='major', labelsize=10)
    
    # Add final values as text
    final_loss = losses[-1] if losses else 0
    final_success = success_rate[-1] if success_rate else 0
    
    ax1.text(0.02, 0.98, f'Final Loss: {final_loss:.4f}', 
             transform=ax1.transAxes, verticalalignment='top',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    ax2.text(0.02, 0.98, f'Final Success: {final_success:.2%}', 
             transform=ax2.transAxes, verticalalignment='top',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    plt.tight_layout()
    
    # Save plot
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    plot_filename = f"{save_path}/training_results_{timestamp}.png"
    plt.savefig(plot_filename, dpi=300, bbox_inches='tight')
    plt.close()
    
    # Save data as JSON
    data_filename = f"{save_path}/training_data_{timestamp}.json"
    training_data = {
        'timestamp': timestamp,
        'losses': losses,
        'successes': successes,
        'success_rate': success_rate.tolist(),
        'final_loss': final_loss,
        'final_success_rate': final_success
    }
    
    with open(data_filename, 'w') as f:
        json.dump(training_data, f, indent=2)
    
    print(f"Training results saved to {plot_filename} and {data_filename}")
    return plot_filename, data_filename

def create_training_report(training_history, save_path="results"):
    """Create a comprehensive training report"""
    os.makedirs(save_path, exist_ok=True)
    
    # Extract data from training history
    episodes = [entry['episode'] for entry in training_history]
    losses = [entry['loss'] for entry in training_history]
    successes = [entry['success'] for entry in training_history]
    
    # Create comprehensive report
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))
    
    # Plot 1: Loss over time
    ax1.plot(episodes, losses, 'b-', linewidth=2)
    ax1.set_title('Training Loss Over Time', fontsize=14, fontweight='bold')
    ax1.set_xlabel('Episode')
    ax1.set_ylabel('Loss')
    ax1.grid(True, alpha=0.3)
    
    # Plot 2: Success rate
    success_rate = np.cumsum(successes) / (np.arange(len(successes)) + 1)
    ax2.plot(episodes, success_rate, 'g-', linewidth=2)
    ax2.set_title('Success Rate Over Time', fontsize=14, fontweight='bold')
    ax2.set_xlabel('Episode')
    ax2.set_ylabel('Success Rate')
    ax2.grid(True, alpha=0.3)
    ax2.set_ylim(0, 1)
    
    # Plot 3: Success distribution
    success_count = sum(successes)
    failure_count = len(successes) - success_count
    ax3.bar(['Success', 'Failure'], [success_count, failure_count], 
            color=['green', 'red'], alpha=0.7)
    ax3.set_title('Success/Failure Distribution', fontsize=14, fontweight='bold')
    ax3.set_ylabel('Count')
    
    # Plot 4: Loss distribution
    ax4.hist(losses, bins=20, color='blue', alpha=0.7, edgecolor='black')
    ax4.set_title('Loss Distribution', fontsize=14, fontweight='bold')
    ax4.set_xlabel('Loss')
    ax4.set_ylabel('Frequency')
    
    plt.tight_layout()
    
    # Save report
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_filename = f"{save_path}/training_report_{timestamp}.png"
    plt.savefig(report_filename, dpi=300, bbox_inches='tight')
    plt.close()
    
    return report_filename