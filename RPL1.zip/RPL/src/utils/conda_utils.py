import os
import sys
import subprocess
import importlib
import platform
import json
from pathlib import Path
from typing import Dict, List, Tuple, Optional

class CondaEnvironmentManager:
    """Manager for Conda environment setup and verification"""
    
    def __init__(self, required_env_name="RPL_ur5e"):
        self.required_env_name = required_env_name
        self.current_env = self.get_current_environment()
        self.required_packages = self._get_required_packages()
        self.conda_path = self._find_conda()
        
    def _find_conda(self) -> str:
        """Find conda executable path"""
        try:
            # Try to find conda using which/where
            if platform.system() == "Windows":
                result = subprocess.run(["where", "conda"], capture_output=True, text=True)
            else:
                result = subprocess.run(["which", "conda"], capture_output=True, text=True)
            
            if result.returncode == 0:
                return result.stdout.strip()
            
            # Try common conda paths
            common_paths = [
                os.path.expanduser("~/anaconda3/bin/conda"),
                os.path.expanduser("~/miniconda3/bin/conda"),
                os.path.expanduser("~/opt/anaconda3/bin/conda"),
                "/opt/anaconda3/bin/conda",
                "/opt/miniconda3/bin/conda",
            ]
            
            for path in common_paths:
                if os.path.exists(path):
                    return path
                    
        except Exception as e:
            print(f"Error finding conda: {e}")
            
        return "conda"  # Fallback to assuming conda is in PATH
    
    def _get_required_packages(self) -> Dict[str, str]:
        """Get list of required packages and their conda names"""
        return {
            'numpy': 'numpy',
            'PIL': 'pillow',
            'matplotlib': 'matplotlib',
            'yaml': 'pyyaml',
            'shapely': 'shapely',
            'pybullet': 'pybullet',
            'PyQt5': 'pyqt',
            'torch': 'pytorch',
            'torchvision': 'torchvision',
            'openai': 'openai',
            'cv2': 'opencv-python',
            'astunparse': 'astunparse',
            'gdown': 'gdown'
        }
    
    def get_current_environment(self) -> str:
        """Get current conda environment name"""
        try:
            env_name = os.environ.get('CONDA_DEFAULT_ENV', '')
            if not env_name:
                # Try to get environment from conda info
                result = subprocess.run([self.conda_path, "info", "--json"], 
                                      capture_output=True, text=True)
                if result.returncode == 0:
                    info = json.loads(result.stdout)
                    env_name = info.get('active_prefix_name', 'base')
            return env_name
        except:
            return "unknown"
    
    def is_correct_environment(self) -> bool:
        """Check if running in the correct conda environment"""
        return self.current_env == self.required_env_name
    
    def check_packages(self) -> Tuple[bool, List[str]]:
        """Check if all required packages are installed"""
        missing_packages = []
        
        for import_name, conda_name in self.required_packages.items():
            try:
                importlib.import_module(import_name)
            except ImportError:
                missing_packages.append(conda_name)
        
        return len(missing_packages) == 0, missing_packages
    
    def install_packages(self, packages: List[str], use_conda: bool = True) -> bool:
        """Install packages using conda or pip"""
        try:
            if use_conda:
                # Try conda first
                cmd = [self.conda_path, "install", "-c", "conda-forge", "-y"] + packages
                result = subprocess.run(cmd, check=True)
                if result.returncode == 0:
                    return True
                
                # If conda fails, try pip
                print("Conda installation failed, trying pip...")
            
            # Use pip
            pip_cmd = [sys.executable, "-m", "pip", "install"] + packages
            result = subprocess.run(pip_cmd, check=True)
            return result.returncode == 0
            
        except subprocess.CalledProcessError as e:
            print(f"Failed to install packages: {e}")
            return False
    
    def create_environment(self, env_file: str = "environment.yml") -> bool:
        """Create conda environment from file"""
        try:
            if not os.path.exists(env_file):
                print(f"Environment file {env_file} not found")
                return False
            
            cmd = [self.conda_path, "env", "create", "-f", env_file]
            result = subprocess.run(cmd, check=True)
            return result.returncode == 0
            
        except subprocess.CalledProcessError as e:
            print(f"Failed to create environment: {e}")
            return False
    
    def activate_environment(self) -> bool:
        """Attempt to activate the required environment"""
        try:
            # This is tricky from within Python, so we'll provide instructions
            print(f"Please activate the environment manually using:")
            print(f"conda activate {self.required_env_name}")
            return True
            
        except Exception as e:
            print(f"Error activating environment: {e}")
            return False
    
    def setup_environment(self, auto_install: bool = False) -> bool:
        """Setup the complete environment"""
        print("=" * 60)
        print("Conda Environment Setup for UR5e Robot Control")
        print("=" * 60)
        
        # Check current environment
        print(f"Current environment: {self.current_env}")
        print(f"Required environment: {self.required_env_name}")
        
        if not self.is_correct_environment():
            print("⚠️  WARNING: Not in the correct conda environment!")
            print("Please run: conda activate RPL_ur5e")
            if not self.activate_environment():
                return False
        
        # Check packages
        all_ok, missing_packages = self.check_packages()
        
        if all_ok:
            print("✅ All required packages are installed")
            return True
        

        print(f"Missing packages: {', '.join(missing_packages)}")
        
        if auto_install:
            response = "y"
        else:
            response = input("Install missing packages? (y/N): ")
        
        if response.lower() == 'y':
            print("Installing missing packages...")
            success = self.install_packages(missing_packages)
            if success:
                print("✅ Packages installed successfully")
                
                # Verify installation
                all_ok, still_missing = self.check_packages()
                if all_ok:
                    print("✅ All packages verified")
                    return True
                else:
                    print(f"❌ Still missing packages: {', '.join(still_missing)}")
                    return False
            else:
                print("❌ Failed to install packages")
                return False
        else:
            print("Installation cancelled")
            return False

def check_environment() -> bool:
    """Check if environment is properly set up"""
    manager = CondaEnvironmentManager()
    return manager.setup_environment()

def install_missing_packages() -> bool:
    """Install missing packages automatically"""
    manager = CondaEnvironmentManager()
    all_ok, missing_packages = manager.check_packages()
    
    if all_ok:
        print("All packages are already installed")
        return True
    
    return manager.install_packages(missing_packages)

def create_conda_environment(env_file: str = "environment.yml") -> bool:
    """Create conda environment from file"""
    manager = CondaEnvironmentManager()
    return manager.create_environment(env_file)

def get_environment_info() -> Dict:
    """Get detailed information about the current environment"""
    manager = CondaEnvironmentManager()
    
    info = {
        'current_environment': manager.current_env,
        'required_environment': manager.required_env_name,
        'correct_environment': manager.is_correct_environment(),
        'conda_path': manager.conda_path,
        'python_version': sys.version,
        'platform': platform.platform(),
    }
    
    # Check packages
    all_ok, missing_packages = manager.check_packages()
    info['packages_ok'] = all_ok
    info['missing_packages'] = missing_packages
    
    return info

def export_environment(export_path: str = "environment_export.yml") -> bool:
    """Export current environment to file"""
    try:
        manager = CondaEnvironmentManager()
        cmd = [manager.conda_path, "env", "export", "--no-builds", "-f", export_path]
        result = subprocess.run(cmd, check=True)
        
        if result.returncode == 0:
            print(f"Environment exported to {export_path}")
            return True
        return False
        
    except subprocess.CalledProcessError as e:
        print(f"Failed to export environment: {e}")
        return False

def check_gpu_support() -> Dict:
    """Check GPU availability and support"""
    gpu_info = {
        'cuda_available': False,
        'cudnn_available': False,
        'gpu_devices': [],
        'pytorch_gpu': False
    }
    
    try:
        # Check NVIDIA GPU
        if platform.system() == "Windows":
            result = subprocess.run(["nvidia-smi", "--list-gpus"], 
                                  capture_output=True, text=True)
        else:
            result = subprocess.run(["nvidia-smi", "--list-gpus"], 
                                  capture_output=True, text=True)
        
        if result.returncode == 0:
            gpu_info['gpu_devices'] = result.stdout.strip().split('\n')
            
        # Check CUDA
        try:
            import torch
            gpu_info['pytorch_gpu'] = torch.cuda.is_available()
            if gpu_info['pytorch_gpu']:
                gpu_info['cuda_version'] = torch.version.cuda
                gpu_info['gpu_count'] = torch.cuda.device_count()
                gpu_info['gpu_names'] = [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]
        except ImportError:
            pass
            
    except Exception as e:
        print(f"Error checking GPU: {e}")
    
    return gpu_info

def setup_project_directories() -> bool:
    """Create necessary project directories"""
    directories = [
        "assets",
        "assets/ur5e",
        "assets/robotiq_2f_85",
        "assets/bowl",
        "trained_policies",
        "trained_policies/demonstrations",
        "videos",
        "results",
        "src/config"
    ]
    
    try:
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
            print(f"Created directory: {directory}")
        return True
    except Exception as e:
        print(f"Error creating directories: {e}")
        return False

def download_assets() -> bool:
    """Download required assets"""
    assets = {
        'ur5e': '1Cc_fDSBL6QiDvNT4dpfAEbhbALSVoWcc',
        'robotiq_2f_85': '1yOMEm-Zp_DL3nItG9RozPeJAmeOldekX',
        'bowl': '1GsqNLhEl9dd4Mc3BM0dX3MibOI1FVWNM'
    }
    
    try:
        # Try to import gdown
        try:
            import gdown
        except ImportError:
            print("gdown not installed, installing...")
            subprocess.run([sys.executable, "-m", "pip", "install", "gdown"], check=True)
            import gdown
        
        for asset_name, file_id in assets.items():
            zip_path = f"assets/{asset_name}.zip"
            extract_path = f"assets/{asset_name}"
            
            if not os.path.exists(extract_path) or not os.listdir(extract_path):
                print(f"Downloading {asset_name}...")
                gdown.download(f"https://drive.google.com/uc?id={file_id}", zip_path, quiet=False)
                
                # Extract
                import zipfile
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall(extract_path)
                
                # Clean up
                os.remove(zip_path)
                print(f"Downloaded and extracted {asset_name}")
            else:
                print(f"{asset_name} already exists")
        
        return True
        
    except Exception as e:
        print(f"Error downloading assets: {e}")
        return False

def create_default_config() -> bool:
    """Create default configuration file"""
    config_content = """openai:
  api_key: "your-api-key-here"
  engine: "text-davinci-003"
  max_tokens: 512
  temperature: 0

lmp:
  tabletop_ui:
    prompt_text: "prompt content here"
    engine: "text-davinci-003"
    max_tokens: 512
    temperature: 0
    query_prefix: "# "
    query_suffix: "."
    stop: ["#", "objects = ["]
    maintain_session: true
    debug_mode: false
    include_context: true
    has_return: false
    return_val_name: "ret_val"

rpl:
  input_size: 256
  hidden_size: 128
  output_size: 6
  learning_rate: 0.001
  replay_buffer_size: 10000
  batch_size: 32
  num_epochs: 100
  validation_split: 0.2

env:
  objects:
    - "blue block"
    - "red block"
    - "green block"
    - "blue bowl"
    - "red bowl"
    - "green bowl"
  time_step: 0.0041667
  render: true
  gui: false
"""
    
    try:
        config_path = "src/config/config.yaml"
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        
        if not os.path.exists(config_path):
            with open(config_path, 'w') as f:
                f.write(config_content)
            print(f"Created default config: {config_path}")
        else:
            print(f"Config already exists: {config_path}")
        
        return True
    except Exception as e:
        print(f"Error creating config: {e}")
        return False

def complete_setup() -> bool:
    """Complete project setup"""
    print("Starting complete project setup...")
    
    # Step 1: Check environment
    manager = CondaEnvironmentManager()
    if not manager.is_correct_environment():
        print("Please activate the correct environment first:")
        print(f"conda activate {manager.required_env_name}")
        return False
    
    # Step 2: Check and install packages
    all_ok, missing_packages = manager.check_packages()
    if missing_packages:
        print("Installing missing packages...")
        if not manager.install_packages(missing_packages):
            return False
    
    # Step 3: Create directories
    if not setup_project_directories():
        return False
    
    # Step 4: Download assets
    if not download_assets():
        return False
    
    # Step 5: Create config
    if not create_default_config():
        return False
    
    # Step 6: Check GPU
    gpu_info = check_gpu_support()
    if gpu_info['pytorch_gpu']:
        print("✅ GPU support detected")
    else:
        print("ℹ️  No GPU detected, will use CPU")
    
    print("✅ Setup completed successfully!")
    print("\nNext steps:")
    print("1. Add your OpenAI API key to src/config/config.yaml")
    print("2. Run the application: python src/main.py")
    
    return True

def main():
    """Main function for command-line usage"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Conda Utilities for UR5e Project")
    parser.add_argument('--check', action='store_true', help='Check environment')
    parser.add_argument('--setup', action='store_true', help='Complete setup')
    parser.add_argument('--info', action='store_true', help='Show environment info')
    parser.add_argument('--export', action='store_true', help='Export environment')
    parser.add_argument('--gpu', action='store_true', help='Check GPU support')
    
    args = parser.parse_args()
    
    if args.check:
        check_environment()
    elif args.setup:
        complete_setup()
    elif args.info:
        info = get_environment_info()
        print(json.dumps(info, indent=2))
    elif args.export:
        export_environment()
    elif args.gpu:
        gpu_info = check_gpu_support()
        print(json.dumps(gpu_info, indent=2))
    else:
        parser.print_help()

if __name__ == "__main__":
    main()