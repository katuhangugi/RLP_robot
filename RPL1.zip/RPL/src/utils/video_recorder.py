import cv2
import os
from datetime import datetime


class VideoRecorder:
    def __init__(self, width=640, height=480, fps=30):
        self.width = width
        self.height = height
        self.fps = fps
        self.writer = None
        self.recording = False

    def start_recording(self):
        if not self.recording:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            video_path = f"videos/operation_{timestamp}.mp4"
            os.makedirs(os.path.dirname(video_path), exist_ok=True)

            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            self.writer = cv2.VideoWriter(video_path, fourcc, self.fps, (self.width, self.height))
            self.recording = True

    def stop_recording(self):
        if self.recording and self.writer:
            self.writer.release()
            self.writer = None
            self.recording = False

    def add_frame(self, frame):
        if self.recording and self.writer:
            self.writer.write(frame)