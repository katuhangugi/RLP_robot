#!/bin/bash



# Full path to conda
CONDA="/home/ngugi/miniconda3/bin/conda"
ENV_NAME="RPL_ur5e"

cd "$(dirname "$0")/src" || {
    echo "Error: Could not find src directory."
    exit 1
}

echo "Checking environment..."
"$CONDA" run -n "$ENV_NAME" python -c "from utils.conda_utils import check_environment; check_environment()"

if [ $? -ne 0 ]; then
    echo "Environment check failed. Please ensure the environment is set up with:"
    echo "  $CONDA env create -f environment.yml"
    exit 1
fi

echo "Starting UR5e Robot Control Application..."
"$CONDA" run -n "$ENV_NAME" python main.py
