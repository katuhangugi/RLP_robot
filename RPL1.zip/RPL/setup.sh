#!/bin/bash

# UR5e Robot Control Project Setup Script for Conda on Linux
# Download assets
echo "Downloading assets..."
mkdir -p assets
cd assets

# Download UR5e assets
if [ ! -d "ur5e" ]; then
    echo "Downloading UR5e assets..."
    gdown --id 1Cc_fDSBL6QiDvNT4dpfAEbhbALSVoWcc -O ur5e.zip
    unzip ur5e.zip -d ur5e/
    rm ur5e.zip
fi

# Download gripper assets
if [ ! -d "robotiq_2f_85" ]; then
    echo "Downloading Robotiq 2F85 assets..."
    gdown --id 1yOMEm-Zp_DL3nItG9RozPeJAmeOldekX -O robotiq_2f_85.zip
    unzip robotiq_2f_85.zip -d robotiq_2f_85/
    rm robotiq_2f_85.zip
fi

# Download bowl assets
if [ ! -d "bowl" ]; then
    echo "Downloading bowl assets..."
    gdown --id 1GsqNLhEl9dd4Mc3BM0dX3MibOI1FVWNM -O bowl.zip
    unzip bowl.zip -d bowl/
    rm bowl.zip
fi

cd ..

# Create necessary directories
echo "Creating directories..."
mkdir -p trained_policies videos results

# Set up OpenAI API key
if [ ! -f "src/config/config.yaml" ]; then
    echo "Creating config file..."
    mkdir -p src/config
    cat > src/config/config.yaml << EOL
openai:
  api_key: "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"
  engine: "text-davinci-003"
  max_tokens: 512
  temperature: 0

lmp:
  tabletop_ui:
    prompt_text: "prompt content here"
    engine: "text-davinci-003"
    max_tokens: 512
    temperature: 0
    query_prefix: "# "
    query_suffix: "."
    stop: ["#", "objects = ["]
    maintain_session: true
    debug_mode: false
    include_context: true
    has_return: false
    return_val_name: "ret_val"

rpl:
  input_size: 500
  hidden_size: 128
  output_size: 12
  learning_rate: 0.005

batch_size: 128
gamma: 0.99
tau: 0.005
noise_eps: 0.50
random_eps: 0.50
n_epochs: 500
n_cycles: 100
n_batches: 80
n_test_rollouts: 30

replay_strategy: future
clip_return: true

env:
  objects:
    - "blue block"
    - "red block"
    - "green block"
    - "blue bowl"
    - "red bowl"
    - "green bowl"
EOL
fi

echo "Please add your OpenAI API key to src/config/config.yaml"
echo "Setup complete! Activate the environment with: conda activate RPL_ur5e"
echo "Run the application with: ./launch_app.sh"
