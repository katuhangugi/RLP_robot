# UR5e Robot Control with Natural Language Commands

This project enables natural language control of a UR5e robot in simulation using Language Model Programs (LMPs) and Reinforcement Learning (RPL).

## Features

- Natural language command processing using OpenAI GPT
- PyBullet simulation environment with UR5e robot
- PyQt5-based GUI for interactive control
- Real-time video recording of operations
- RPL training and policy saving
- Training visualization and results plotting

## Installation with Conda

1. **Run the setup script:**
   ```bash
   chmod +x conda_setup.sh
   ./conda_setup.sh